#!/usr/bin/env bash
# In access token từ Keycloak local để gọi API bằng curl/Postman.
#
#   scripts/dev/token.sh editor            # user mẫu (password mặc định: strata)
#   scripts/dev/token.sh manager mypass    # password khác
#   scripts/dev/token.sh erp               # service account ERP (client credentials)
#
# Dùng client dev-cli (direct grant) - client này CHỈ có trong realm local.
set -euo pipefail

KC_URL="${KC_URL:-http://localhost:8081}"
TOKEN_URL="$KC_URL/realms/strata/protocol/openid-connect/token"
who="${1:-editor}"
pass="${2:-strata}"

if [[ "$who" == "erp" ]]; then
  resp=$(curl -fsS -X POST "$TOKEN_URL" \
    -d grant_type=client_credentials -d client_id=erp -d client_secret="${ERP_CLIENT_SECRET:-erp-dev-secret}")
else
  resp=$(curl -fsS -X POST "$TOKEN_URL" \
    -d grant_type=password -d client_id=dev-cli -d scope=openid \
    --data-urlencode username="$who" --data-urlencode password="$pass")
fi

token=$(printf '%s' "$resp" | sed -nE 's/.*"access_token":"([^"]+)".*/\1/p')
if [[ -z "$token" ]]; then
  echo "Không lấy được token: $resp" >&2
  exit 1
fi
printf '%s\n' "$token"
