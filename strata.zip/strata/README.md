# Strata - Bảng giá sản phẩm (CQRS + SCD2)

Monorepo của hệ thống Strata: backend Go (CQRS, PostgreSQL là nguồn sự thật, CDC qua
Debezium/Kafka sang Elasticsearch) và frontend React + AG Grid.

Tài liệu gốc (ở thư mục cha): `PLM_Spec_Bang_Gia_San_Pham_v1.0.docx` (SPEC),
`Strata_Backend_Architecture_v1.0.docx` (ARCH), `Strata_Luong_Kien_Truc_v1.0.docx` (FLOW),
`Strata_UIUX_v1.0.docx` (UX), `Strata_Ke_Hoach_Phase_v1.0.docx` (PLAN).

**Trạng thái:** PH-01 - Nền tảng & môi trường dev (PLAN §3.1) đã xong. Xem
[docs/phases/PH-01.md](docs/phases/PH-01.md) để biết đã làm gì và cách nghiệm thu.

---

## 1. Yêu cầu máy dev

| Công cụ | Phiên bản | Ghi chú |
| --- | --- | --- |
| Docker Desktop (Compose v2) | mới | Cấp ≥ 8 GB RAM cho Docker (stack ~12 container) |
| Go | 1.24+ | Chỉ cần khi chạy/test backend ngoài container |
| Node.js | 20 LTS+ | Frontend |
| make, bash, curl | | Windows: dùng **WSL2 (Ubuntu)** - khuyến nghị - hoặc Git Bash |

> **Windows:** clone repo vào filesystem của WSL (ví dụ `~/code/strata`) thay vì `C:\...`
> để Docker và Vite chạy nhanh, và giữ line ending LF (đã cấu hình trong `.gitattributes`).

## 2. Chạy nhanh

```bash
make up                 # hạ tầng + migration + topic + ES + bucket + 6 service Go, chờ healthy
cd web && npm ci && npm run dev    # http://localhost:5173
```

Đăng nhập bằng một trong các user mẫu (mật khẩu đều là `strata`):

| User | Vai trò | Phạm vi NCC | Thấy trên sidebar |
| --- | --- | --- | --- |
| `viewer` | VIEWER | tất cả (`*`) | Giá hiện hành, Tra cứu as-of |
| `editor` | PRICING_EDITOR | ACME, BMI | + File version, Chờ duyệt |
| `manager` | PRICING_MANAGER | ACME, BMI, CPC | + Dashboard |
| `auditor` | AUDITOR | tất cả | Giá hiện hành, File version, Tra cứu as-of, Dashboard |
| `admin` | ADMIN | tất cả | + Quản trị |

Service account cho ERP/OMS: client `erp`, secret `erp-dev-secret` (role SYSTEM).

Kiểm tra API nhanh:

```bash
make me AS=editor       # GET /api/v1/query/me với token của editor
make me AS=erp          # bằng service account (client credentials)
make token AS=manager   # in access token để dùng với curl/Postman
```

## 3. Địa chỉ local

| Thành phần | URL | Tài khoản |
| --- | --- | --- |
| Web (Vite) | http://localhost:5173 | user mẫu ở trên |
| command-svc | http://localhost:8080/api/v1/commands | Bearer token |
| query-svc | http://localhost:8082/api/v1/query | Bearer token |
| Keycloak | http://localhost:8081 (admin console: `/admin`) | admin / admin |
| Grafana | http://localhost:3000 | admin / admin |
| Prometheus | http://localhost:9090 | |
| Jaeger (trace) | http://localhost:16686 | |
| MinIO console | http://localhost:9001 | minio / minio12345 |
| Elasticsearch | http://localhost:9200 | |
| Debezium Connect | http://localhost:8083 | |
| PostgreSQL | localhost:5432, db `pricing` | app / app |
| Kafka (từ host) | localhost:29092 | |

Mỗi service Go còn có cổng admin nội bộ `:8090` (`/livez`, `/readyz`, `/metrics`, `/debug/pprof`),
không publish ra host khi chạy trong container.

## 4. Lệnh thường dùng

`make help` liệt kê đầy đủ. Hay dùng nhất:

| Lệnh | Việc |
| --- | --- |
| `make up` / `make down` / `make reset` | Dựng / dừng / dừng và xoá dữ liệu |
| `make infra` | Chỉ hạ tầng (để chạy service bằng `go run`) |
| `make run-query` / `make run-command` | Chạy service trên host (cần `cp .env.example .env`) |
| `make migrate` / `make migrate-new NAME=...` | Migration (goose) |
| `make sqlc` | Sinh code từ `db/queries/*.sql` |
| `make topics` / `make es-init` | Tạo topic Kafka / index ES |
| `make test` / `make lint` | Test (race) / lint (gồm kiểm tra phụ thuộc giữa các lớp) |
| `make kc-reset` | Import lại realm Keycloak sau khi sửa `deploy/keycloak/strata-realm.json` |
| `make check` | Toàn bộ kiểm tra backend + frontend trước khi commit |

Frontend (`web/`): `npm run dev`, `npm test`, `npm run lint`, `npm run typecheck`, `npm run build`.

## 5. Cấu trúc repo

```
cmd/                      composition root của từng binary (ADR-001)
  command-svc/ query-svc/ import-worker/ projector/ notifier/ jobs/
internal/
  domain/                 nghiệp vụ thuần Go (identity, apperr; price, fileversion... từ PH-03)
  app/port/               interface ứng dụng cần từ hạ tầng
  adapter/in/http/        router, middleware, problem+json, route query/command
  adapter/out/            oidc (verify JWT), postgres (pgxpool + sqlc)
  platform/               config, log, otel, metrics, health, lifecycle, service kit
db/migrations/ db/queries/  goose + sqlc
schemas/events/           JSON Schema của event (từ PH-03)
deploy/                   docker-compose, Dockerfile, Keycloak realm, Kafka, ES, Prometheus, Grafana
web/                      React 18 + TypeScript + Vite
docs/                     hướng dẫn dev, cấu hình, nhật ký lệch so với tài liệu gốc
```

Đọc tiếp:

- [docs/development.md](docs/development.md) - kiến trúc code, quy ước, cách thêm tính năng mới.
- [docs/configuration.md](docs/configuration.md) - toàn bộ biến môi trường.
- [docs/deviations.md](docs/deviations.md) - các điểm khác/bổ sung so với tài liệu gốc (cần cập nhật tài liệu).

## 6. Xử lý sự cố

| Hiện tượng | Cách xử lý |
| --- | --- |
| `make up` báo container unhealthy | `make ps`, rồi `make logs S=<tên>`. Elasticsearch/Kafka cần RAM: tăng bộ nhớ Docker. |
| Cổng bị chiếm (5432, 8080...) | Tắt dịch vụ đang dùng cổng đó, hoặc đổi cổng publish trong `deploy/docker-compose.yml`. |
| Web báo "Không đăng nhập được" | Keycloak chưa healthy (`make ps`); realm import lại bằng `make kc-reset`. |
| API trả 401 dù đã đăng nhập | Kiểm tra `OIDC_ISSUER` của service trùng `iss` trong token (`http://localhost:8081/realms/strata`). |
| `make run-*` báo cổng bận | Dừng container tương ứng: `docker compose -f deploy/docker-compose.yml stop query-svc`. |
