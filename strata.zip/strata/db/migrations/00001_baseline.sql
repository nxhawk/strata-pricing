-- Baseline của schema Strata (PH-01).
--
-- Chưa có bảng nghiệp vụ: master data đến ở PH-02, SCD2/outbox ở PH-03.
-- Quy ước migration (ARCH §7.5):
--   * goose, file SQL thuần, đánh số tăng dần 0000N_<mô_tả>.sql
--   * chỉ thêm theo hướng expand -> migrate -> contract, không đổi tên cột 1 bước
--   * index trên bảng lớn: CREATE INDEX CONCURRENTLY trong migration riêng
--     có annotation goose "NO TRANSACTION" ở đầu file

-- Migration rỗng có chủ đích: xác nhận chuỗi goose + sqlc chạy thông (PLAN PH-01).

-- +goose Up
SELECT 1;

-- +goose Down
SELECT 1;
