-- name: Ping :one
-- Ping chạy một truy vấn thật tới PostgreSQL, dùng cho /readyz.
SELECT 1::int4 AS ok;
