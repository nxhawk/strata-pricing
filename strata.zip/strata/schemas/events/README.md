# Event schema

JSON Schema của từng event (ADR-008, SPEC §10.4 - §10.5), dạng `<EventType>.v<N>.schema.json`.
Event đầu tiên (`PriceChanged`) được thêm ở PH-03. Mỗi event mới phải có schema ở đây
(Definition of Done chung, PLAN §2.5).
