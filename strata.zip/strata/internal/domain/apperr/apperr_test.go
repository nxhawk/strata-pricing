package apperr_test

import (
	"errors"
	"fmt"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
)

func TestError_WrapAndUnwrap(t *testing.T) {
	root := errors.New("pg down")
	err := fmt.Errorf("load: %w", apperr.Unavailable("db", root))

	assert.True(t, errors.Is(err, root))
	assert.Equal(t, apperr.KindUnavailable, apperr.KindOf(err))

	e, ok := apperr.As(err)
	assert.True(t, ok)
	assert.Equal(t, apperr.CodeUnavailable, e.Code)
}

func TestError_IsMatchesByCode(t *testing.T) {
	err := fmt.Errorf("x: %w", apperr.Conflict(apperr.CodeVersionConflict, "changed", nil))
	assert.True(t, errors.Is(err, &apperr.Error{Code: apperr.CodeVersionConflict}))
	assert.False(t, errors.Is(err, &apperr.Error{Code: apperr.CodeInvalidState}))
}

func TestKindOf_PlainError(t *testing.T) {
	assert.Equal(t, apperr.KindUnknown, apperr.KindOf(errors.New("boom")))
}

func TestWithDetails_DoesNotMutateOriginal(t *testing.T) {
	base := apperr.Conflict("X", "m", nil)
	withD := base.WithDetails(map[string]any{"a": 1})
	assert.Nil(t, base.Details)
	assert.Equal(t, 1, withD.Details["a"])
}
