package apperr

// Mã lỗi ổn định trả cho client (SPEC §13.4). Frontend dịch mã sang microcopy
// (UX §12.3), vì vậy KHÔNG đổi tên mã đã phát hành.
const (
	CodeValidation         = "VALIDATION_ERROR"
	CodeUnauthenticated    = "UNAUTHENTICATED"
	CodeForbidden          = "FORBIDDEN"
	CodeSupplierOutOfScope = "SUPPLIER_OUT_OF_SCOPE"
	CodeNotFound           = "NOT_FOUND"
	CodeMethodNotAllowed   = "METHOD_NOT_ALLOWED"
	CodeVersionConflict    = "VERSION_CONFLICT"
	CodeDuplicateFile      = "DUPLICATE_FILE"
	CodeInvalidState       = "INVALID_STATE"
	CodePublishConflict    = "PUBLISH_CONFLICT"
	CodePublishInProgress  = "PUBLISH_IN_PROGRESS"
	CodeFileTooLarge       = "FILE_TOO_LARGE"
	CodePayloadTooLarge    = "PAYLOAD_TOO_LARGE"
	CodeUnsupportedFormat  = "UNSUPPORTED_FORMAT"
	CodeReasonRequired     = "REASON_REQUIRED"
	CodeFourEyesViolation  = "FOUR_EYES_VIOLATION"
	CodeRetroactive        = "RETROACTIVE_NOT_ALLOWED"
	CodeIdempotencyReused  = "IDEMPOTENCY_KEY_REUSED"
	CodeRateLimited        = "RATE_LIMITED"
	CodeInternal           = "INTERNAL"
	CodeUnavailable        = "UNAVAILABLE"
)
