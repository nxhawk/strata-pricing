// Package apperr là mô hình lỗi chung (ARCH §5.5): domain và application trả
// lỗi có kiểu; chỉ adapter (HTTP, Kafka...) quyết định ánh xạ sang giao thức.
package apperr

import (
	"errors"
	"fmt"
)

// Kind là loại lỗi, quyết định cách xử lý ở biên (HTTP status, retry...).
type Kind uint8

const (
	KindUnknown         Kind = iota
	KindInvalid              // 400 / 422 - dữ liệu hoặc quy tắc nghiệp vụ
	KindUnauthenticated      // 401
	KindForbidden            // 403
	KindNotFound             // 404
	KindConflict             // 409
	KindUnavailable          // 503 - có thể thử lại
	KindInternal             // 500
)

func (k Kind) String() string {
	switch k {
	case KindInvalid:
		return "Invalid"
	case KindUnauthenticated:
		return "Unauthenticated"
	case KindForbidden:
		return "Forbidden"
	case KindNotFound:
		return "NotFound"
	case KindConflict:
		return "Conflict"
	case KindUnavailable:
		return "Unavailable"
	case KindInternal:
		return "Internal"
	default:
		return "Unknown"
	}
}

// FieldError mô tả lỗi của một trường đầu vào.
type FieldError struct {
	Field   string `json:"field"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

// Error là lỗi ứng dụng có kiểu.
type Error struct {
	Kind    Kind
	Code    string         // mã ổn định cho client, ví dụ "VERSION_CONFLICT" (SPEC §13.4)
	Msg     string         // mô tả ngắn, an toàn để trả cho client
	Fields  []FieldError   // lỗi từng trường (VALIDATION_ERROR)
	Details map[string]any // dữ liệu kèm theo (snapshot hiện tại...)
	Err     error          // nguyên nhân gốc - KHÔNG lộ ra client
}

func (e *Error) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Msg, e.Err)
	}
	return e.Code + ": " + e.Msg
}

func (e *Error) Unwrap() error { return e.Err }

// Is cho phép errors.Is(err, &apperr.Error{Code: "X"}) so khớp theo Code.
func (e *Error) Is(target error) bool {
	var t *Error
	if !errors.As(target, &t) {
		return false
	}
	return t.Code != "" && t.Code == e.Code
}

// New tạo lỗi với kind, code và thông điệp.
func New(kind Kind, code, msg string) *Error { return &Error{Kind: kind, Code: code, Msg: msg} }

// Wrap tạo lỗi bọc nguyên nhân gốc.
func Wrap(kind Kind, code, msg string, cause error) *Error {
	return &Error{Kind: kind, Code: code, Msg: msg, Err: cause}
}

// WithDetails trả về bản sao có thêm details.
func (e *Error) WithDetails(d map[string]any) *Error {
	cp := *e
	cp.Details = d
	return &cp
}

// Các hàm tạo nhanh theo kind.

func Invalid(code, msg string, fields ...FieldError) *Error {
	return &Error{Kind: KindInvalid, Code: code, Msg: msg, Fields: fields}
}

func Validation(fields ...FieldError) *Error {
	return Invalid(CodeValidation, "Dữ liệu không hợp lệ", fields...)
}

func Unauthenticated(msg string, cause error) *Error {
	return Wrap(KindUnauthenticated, CodeUnauthenticated, msg, cause)
}

func Forbidden(code, msg string) *Error { return New(KindForbidden, code, msg) }

func NotFound(msg string) *Error { return New(KindNotFound, CodeNotFound, msg) }

func Conflict(code, msg string, details map[string]any) *Error {
	return &Error{Kind: KindConflict, Code: code, Msg: msg, Details: details}
}

func Unavailable(msg string, cause error) *Error {
	return Wrap(KindUnavailable, CodeUnavailable, msg, cause)
}

func Internal(cause error) *Error {
	return Wrap(KindInternal, CodeInternal, "Lỗi hệ thống", cause)
}

// As trích *Error từ chuỗi lỗi.
func As(err error) (*Error, bool) {
	var e *Error
	ok := errors.As(err, &e)
	return e, ok
}

// KindOf trả về kind của lỗi; KindUnknown nếu không phải *Error.
func KindOf(err error) Kind {
	if e, ok := As(err); ok {
		return e.Kind
	}
	return KindUnknown
}
