package identity

import (
	"context"
	"slices"
	"sort"
	"strings"
)

// AllSuppliers là giá trị đặc biệt trong supplier_scope, nghĩa là được truy cập
// mọi nhà cung cấp (dùng cho VIEWER, AUDITOR, ADMIN...). Xem docs/deviations.md.
const AllSuppliers = "*"

// Kind phân biệt người dùng thật và tài khoản dịch vụ (client credentials).
type Kind string

const (
	KindUser    Kind = "user"
	KindService Kind = "service"
)

// Actor là danh tính đã xác thực của một request. Được dựng một lần ở biên
// (middleware authn) rồi truyền qua context; mọi lớp bên trong chỉ đọc.
type Actor struct {
	ID            string // claim sub
	Username      string // preferred_username
	Name          string
	Email         string
	Kind          Kind
	Roles         []Role
	SupplierScope []string
}

// NewActor chuẩn hoá dữ liệu thô từ token: bỏ role lạ, bỏ trùng, sắp xếp ổn định.
func NewActor(id, username, name, email string, kind Kind, rawRoles, rawScope []string) Actor {
	return Actor{
		ID:            id,
		Username:      username,
		Name:          name,
		Email:         email,
		Kind:          kind,
		Roles:         normalizeRoles(rawRoles),
		SupplierScope: normalizeScope(rawScope),
	}
}

// HasRole cho biết actor có vai trò r.
func (a Actor) HasRole(r Role) bool { return slices.Contains(a.Roles, r) }

// HasAnyRole cho biết actor có ít nhất một vai trò trong danh sách.
func (a Actor) HasAnyRole(roles ...Role) bool {
	for _, r := range roles {
		if a.HasRole(r) {
			return true
		}
	}
	return false
}

// Permissions trả về các quyền suy ra từ vai trò.
func (a Actor) Permissions() []Permission { return PermissionsOf(a.Roles) }

// Can cho biết actor có quyền p (chưa xét supplier scope).
func (a Actor) Can(p Permission) bool { return slices.Contains(a.Permissions(), p) }

// CanAccessSupplier cho biết supplierCode có nằm trong phạm vi của actor.
func (a Actor) CanAccessSupplier(supplierCode string) bool {
	code := strings.ToUpper(strings.TrimSpace(supplierCode))
	for _, s := range a.SupplierScope {
		if s == AllSuppliers || s == code {
			return true
		}
	}
	return false
}

// HasAllSuppliers cho biết actor được truy cập mọi nhà cung cấp.
func (a Actor) HasAllSuppliers() bool { return slices.Contains(a.SupplierScope, AllSuppliers) }

func normalizeRoles(raw []string) []Role {
	set := map[Role]struct{}{}
	for _, s := range raw {
		if r, ok := ParseRole(s); ok {
			set[r] = struct{}{}
		}
	}
	out := make([]Role, 0, len(set))
	for _, r := range AllRoles() { // giữ thứ tự của AllRoles
		if _, ok := set[r]; ok {
			out = append(out, r)
		}
	}
	return out
}

func normalizeScope(raw []string) []string {
	set := map[string]struct{}{}
	for _, s := range raw {
		s = strings.ToUpper(strings.TrimSpace(s))
		if s != "" {
			set[s] = struct{}{}
		}
	}
	out := make([]string, 0, len(set))
	for s := range set {
		out = append(out, s)
	}
	sort.Strings(out)
	return out
}

type ctxKey struct{}

// WithActor gắn actor vào context.
func WithActor(ctx context.Context, a Actor) context.Context {
	return context.WithValue(ctx, ctxKey{}, a)
}

// FromContext đọc actor từ context; false nếu request chưa được xác thực.
func FromContext(ctx context.Context) (Actor, bool) {
	a, ok := ctx.Value(ctxKey{}).(Actor)
	return a, ok
}
