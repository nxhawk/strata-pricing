package identity_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/nxhawk/strata-pricing/internal/domain/identity"
)

func TestParseRole_CaseInsensitiveAndUnknown(t *testing.T) {
	tests := []struct {
		in   string
		want identity.Role
		ok   bool
	}{
		{"PRICING_EDITOR", identity.RolePricingEditor, true},
		{" viewer ", identity.RoleViewer, true},
		{"default-roles-strata", "", false},
		{"offline_access", "", false},
		{"", "", false},
	}
	for _, tt := range tests {
		got, ok := identity.ParseRole(tt.in)
		assert.Equal(t, tt.ok, ok, tt.in)
		assert.Equal(t, tt.want, got, tt.in)
	}
}

func TestNewActor_NormalizesRolesAndScope(t *testing.T) {
	a := identity.NewActor("u1", "editor", "Editor", "", identity.KindUser,
		[]string{"offline_access", "PRICING_EDITOR", "VIEWER", "PRICING_EDITOR"},
		[]string{"bmi", " ACME ", "", "BMI"})

	assert.Equal(t, []identity.Role{identity.RoleViewer, identity.RolePricingEditor}, a.Roles)
	assert.Equal(t, []string{"ACME", "BMI"}, a.SupplierScope)
}

func TestActor_CanAccessSupplier(t *testing.T) {
	editor := identity.NewActor("u1", "", "", "", identity.KindUser, nil, []string{"ACME"})
	assert.True(t, editor.CanAccessSupplier("acme"))
	assert.False(t, editor.CanAccessSupplier("BMI"))

	auditor := identity.NewActor("u2", "", "", "", identity.KindUser, nil, []string{identity.AllSuppliers})
	assert.True(t, auditor.CanAccessSupplier("ANY"))
	assert.True(t, auditor.HasAllSuppliers())

	none := identity.NewActor("u3", "", "", "", identity.KindUser, nil, nil)
	assert.False(t, none.CanAccessSupplier("ACME"))
}

func TestPermissionsOf_MatchesRBACMatrix(t *testing.T) {
	tests := []struct {
		role    identity.Role
		allowed []identity.Permission
		denied  []identity.Permission
	}{
		{identity.RoleViewer,
			[]identity.Permission{identity.PermPriceView, identity.PermPriceHistory, identity.PermExportCreate},
			[]identity.Permission{identity.PermFileUpload, identity.PermVersionView, identity.PermAdminManage}},
		{identity.RolePricingEditor,
			[]identity.Permission{identity.PermFileUpload, identity.PermDraftEdit, identity.PermVersionSubmit},
			[]identity.Permission{identity.PermVersionApprove, identity.PermPriceHotfix, identity.PermAuditView}},
		{identity.RolePricingManager,
			[]identity.Permission{identity.PermVersionApprove, identity.PermVersionRollback, identity.PermPriceHotfix, identity.PermAuditView},
			[]identity.Permission{identity.PermAdminManage}},
		{identity.RoleAuditor,
			[]identity.Permission{identity.PermAuditView, identity.PermVersionView},
			[]identity.Permission{identity.PermDraftEdit, identity.PermAdminManage}},
		{identity.RoleAdmin,
			[]identity.Permission{identity.PermAdminManage, identity.PermDashboardView},
			[]identity.Permission{identity.PermDraftEdit, identity.PermVersionApprove}},
		{identity.RoleSystem,
			[]identity.Permission{identity.PermPriceView, identity.PermPriceHistory},
			[]identity.Permission{identity.PermExportCreate, identity.PermVersionView}},
	}
	for _, tt := range tests {
		t.Run(string(tt.role), func(t *testing.T) {
			got := identity.PermissionsOf([]identity.Role{tt.role})
			for _, p := range tt.allowed {
				assert.Contains(t, got, p)
			}
			for _, p := range tt.denied {
				assert.NotContains(t, got, p)
			}
		})
	}
}

func TestPermissionsOf_UnionWithoutDuplicates(t *testing.T) {
	got := identity.PermissionsOf([]identity.Role{identity.RoleViewer, identity.RoleAdmin})
	seen := map[identity.Permission]bool{}
	for _, p := range got {
		require.False(t, seen[p], "duplicate %s", p)
		seen[p] = true
	}
	assert.True(t, seen[identity.PermAdminManage])
}

func TestContext_RoundTrip(t *testing.T) {
	_, ok := identity.FromContext(context.Background())
	assert.False(t, ok)

	a := identity.NewActor("u1", "x", "", "", identity.KindUser, []string{"ADMIN"}, nil)
	got, ok := identity.FromContext(identity.WithActor(context.Background(), a))
	require.True(t, ok)
	assert.Equal(t, a, got)
}
