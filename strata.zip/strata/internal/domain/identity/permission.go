package identity

import "sort"

// Permission là một quyền chức năng. Tên theo dạng <tài nguyên>.<hành động>.
//
// Ma trận dưới đây là nguồn sự thật duy nhất cho RBAC: backend dùng để kiểm tra
// quyền, frontend nhận danh sách quyền qua GET /query/me để ẩn/hiện chức năng
// (không tự suy luận từ role ở phía client).
type Permission string

// Quyền theo SPEC §16.1 (cột "Chức năng") và UX §4.2 (hiển thị điều hướng).
const (
	PermPriceView       Permission = "price.view"       // Xem giá hiện hành / search
	PermPriceHistory    Permission = "price.history"    // Tra as-of / history
	PermFileUpload      Permission = "file.upload"      // Upload file (EDITOR theo scope)
	PermDraftEdit       Permission = "draft.edit"       // Sửa bản nháp / bulk (EDITOR theo scope)
	PermVersionView     Permission = "version.view"     // Xem danh sách File Version (UX §4.2)
	PermVersionSubmit   Permission = "version.submit"   // Submit (EDITOR theo scope)
	PermVersionApprove  Permission = "version.approve"  // Approve / Reject (khác người submit)
	PermVersionDiscard  Permission = "version.discard"  // Discard (EDITOR: chỉ người upload)
	PermVersionRollback Permission = "version.rollback" // Rollback
	PermPriceHotfix     Permission = "price.hotfix"     // Hotfix giá hiện hành
	PermAuditView       Permission = "audit.view"       // Xem audit log
	PermDashboardView   Permission = "dashboard.view"   // Mở Grafana (UX §4.2)
	PermAdminManage     Permission = "admin.manage"     // Quản trị supplier/template/user/ngưỡng
	PermExportCreate    Permission = "export.create"    // Export
)

// rolePermissions hiện thực ma trận SPEC §16.1. Các ràng buộc chi tiết hơn
// (supplier scope, "≠ submitter", "người upload") được Authorizer kiểm tra ở
// application layer từ PH-02, không nằm ở đây.
var rolePermissions = map[Role][]Permission{
	RoleViewer: {
		PermPriceView, PermPriceHistory, PermExportCreate,
	},
	RolePricingEditor: {
		PermPriceView, PermPriceHistory, PermExportCreate,
		PermVersionView, PermFileUpload, PermDraftEdit, PermVersionSubmit, PermVersionDiscard,
	},
	RolePricingManager: {
		PermPriceView, PermPriceHistory, PermExportCreate,
		PermVersionView, PermFileUpload, PermDraftEdit, PermVersionSubmit, PermVersionDiscard,
		PermVersionApprove, PermVersionRollback, PermPriceHotfix,
		PermAuditView, PermDashboardView,
	},
	RoleAuditor: {
		PermPriceView, PermPriceHistory, PermExportCreate,
		PermVersionView, PermAuditView, PermDashboardView,
	},
	RoleAdmin: {
		PermPriceView, PermPriceHistory, PermExportCreate,
		PermVersionView, PermAuditView, PermDashboardView, PermAdminManage,
	},
	// ARCH §11.2 giới hạn thêm SYSTEM chỉ được gọi route as-of; giới hạn theo
	// route được áp ở query-svc khi các route đó ra đời (PH-05, PH-13).
	RoleSystem: {
		PermPriceView, PermPriceHistory,
	},
}

// PermissionsOf trả về hợp các quyền của danh sách vai trò, đã sắp xếp, không trùng.
func PermissionsOf(roles []Role) []Permission {
	set := map[Permission]struct{}{}
	for _, r := range roles {
		for _, p := range rolePermissions[r] {
			set[p] = struct{}{}
		}
	}
	out := make([]Permission, 0, len(set))
	for p := range set {
		out = append(out, p)
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out
}
