// Package identity mô tả "ai đang gọi hệ thống": vai trò, phạm vi nhà cung cấp
// và quyền suy ra từ ma trận RBAC (SPEC §2.3, §16.1).
//
// Package thuần Go (chỉ dùng stdlib) theo quy tắc lớp domain ở ARCH §5.1.
package identity

import "strings"

// Role là vai trò nghiệp vụ, khớp 1-1 với realm role trong Keycloak.
type Role string

// Danh sách vai trò theo SPEC §2.3.
const (
	RoleViewer         Role = "VIEWER"
	RolePricingEditor  Role = "PRICING_EDITOR"
	RolePricingManager Role = "PRICING_MANAGER"
	RoleAuditor        Role = "AUDITOR"
	RoleAdmin          Role = "ADMIN"
	// RoleSystem dành cho hệ thống ngoài (ERP/OMS) gọi bằng client credentials.
	RoleSystem Role = "SYSTEM"
)

// AllRoles trả về mọi vai trò hệ thống biết, theo thứ tự hiển thị ổn định.
func AllRoles() []Role {
	return []Role{RoleViewer, RolePricingEditor, RolePricingManager, RoleAuditor, RoleAdmin, RoleSystem}
}

// ParseRole chuyển chuỗi (không phân biệt hoa thường) thành Role.
// Trả false với vai trò không thuộc hệ thống (ví dụ default-roles-strata,
// offline_access của Keycloak) - các giá trị này bị bỏ qua thay vì báo lỗi.
func ParseRole(s string) (Role, bool) {
	r := Role(strings.ToUpper(strings.TrimSpace(s)))
	for _, known := range AllRoles() {
		if r == known {
			return r, true
		}
	}
	return "", false
}

func (r Role) String() string { return string(r) }
