// Package log dựng logger slog JSON theo ARCH §12.4 / SPEC §19.2:
// mọi bản ghi có ts, level, msg, service, version và - khi có - trace_id,
// span_id cùng các thuộc tính gắn vào context (request_id, user_id...).
//
// Luôn gọi logger.*Context(ctx, ...) trong code xử lý request để các trường
// theo context được thêm tự động.
package log

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"os"
	"strings"
	"time"

	"go.opentelemetry.io/otel/trace"
)

// Config cấu hình logger (biến LOG_LEVEL, LOG_FORMAT).
type Config struct {
	Level  string `env:"LEVEL" envDefault:"info"`  // debug | info | warn | error
	Format string `env:"FORMAT" envDefault:"json"` // json | text (text chỉ để đọc khi dev)
}

// New tạo logger ghi ra stdout.
func New(cfg Config, service, version string) (*slog.Logger, error) {
	return NewWithWriter(os.Stdout, cfg, service, version)
}

// NewWithWriter tạo logger ghi ra w (dùng trong test).
func NewWithWriter(w io.Writer, cfg Config, service, version string) (*slog.Logger, error) {
	var level slog.Level
	if err := level.UnmarshalText([]byte(cfg.Level)); err != nil {
		return nil, fmt.Errorf("log: invalid LOG_LEVEL %q", cfg.Level)
	}
	opts := &slog.HandlerOptions{Level: level, ReplaceAttr: replaceAttr}

	var h slog.Handler
	switch strings.ToLower(cfg.Format) {
	case "", "json":
		h = slog.NewJSONHandler(w, opts)
	case "text":
		h = slog.NewTextHandler(w, opts)
	default:
		return nil, fmt.Errorf("log: invalid LOG_FORMAT %q", cfg.Format)
	}
	return slog.New(contextHandler{h}).With("service", service, "version", version), nil
}

// replaceAttr đổi khoá "time" thành "ts" theo chuẩn log của dự án.
func replaceAttr(groups []string, a slog.Attr) slog.Attr {
	if len(groups) == 0 && a.Key == slog.TimeKey {
		a.Key = "ts"
	}
	return a
}

type attrsKey struct{}

// WithAttrs trả về context mang thêm thuộc tính log. Middleware dùng để gắn
// request_id, user_id... một lần; mọi log sau đó trong request đều có.
func WithAttrs(ctx context.Context, args ...any) context.Context {
	if len(args) == 0 {
		return ctx
	}
	existing, _ := ctx.Value(attrsKey{}).([]slog.Attr)
	r := slog.NewRecord(time.Time{}, 0, "", 0)
	r.Add(args...)
	merged := make([]slog.Attr, 0, len(existing)+r.NumAttrs())
	merged = append(merged, existing...)
	r.Attrs(func(a slog.Attr) bool { merged = append(merged, a); return true })
	return context.WithValue(ctx, attrsKey{}, merged)
}

// contextHandler bổ sung trace_id/span_id (OpenTelemetry) và thuộc tính từ context.
type contextHandler struct{ slog.Handler }

func (h contextHandler) Handle(ctx context.Context, r slog.Record) error {
	if sc := trace.SpanContextFromContext(ctx); sc.IsValid() {
		r.AddAttrs(
			slog.String("trace_id", sc.TraceID().String()),
			slog.String("span_id", sc.SpanID().String()),
		)
	}
	if attrs, ok := ctx.Value(attrsKey{}).([]slog.Attr); ok {
		r.AddAttrs(attrs...)
	}
	return h.Handler.Handle(ctx, r)
}

func (h contextHandler) WithAttrs(attrs []slog.Attr) slog.Handler {
	return contextHandler{h.Handler.WithAttrs(attrs)}
}

func (h contextHandler) WithGroup(name string) slog.Handler {
	return contextHandler{h.Handler.WithGroup(name)}
}
