package log_test

import (
	"bytes"
	"context"
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"

	"github.com/nxhawk/strata-pricing/internal/platform/log"
)

func decode(t *testing.T, b []byte) map[string]any {
	t.Helper()
	var m map[string]any
	require.NoError(t, json.Unmarshal(bytes.TrimSpace(b), &m))
	return m
}

func TestLogger_JSONHasStandardFieldsAndTrace(t *testing.T) {
	var buf bytes.Buffer
	logger, err := log.NewWithWriter(&buf, log.Config{Level: "info", Format: "json"}, "query-svc", "1.0.0")
	require.NoError(t, err)

	tp := sdktrace.NewTracerProvider()
	ctx, span := tp.Tracer("t").Start(context.Background(), "op")
	defer span.End()
	ctx = log.WithAttrs(ctx, "request_id", "r-1")
	ctx = log.WithAttrs(ctx, "user_id", "u-1")

	logger.InfoContext(ctx, "hello")

	m := decode(t, buf.Bytes())
	assert.Equal(t, "hello", m["msg"])
	assert.Equal(t, "INFO", m["level"])
	assert.Equal(t, "query-svc", m["service"])
	assert.Equal(t, "1.0.0", m["version"])
	assert.Contains(t, m, "ts")
	assert.NotContains(t, m, "time")
	assert.Equal(t, span.SpanContext().TraceID().String(), m["trace_id"])
	assert.Equal(t, span.SpanContext().SpanID().String(), m["span_id"])
	assert.Equal(t, "r-1", m["request_id"])
	assert.Equal(t, "u-1", m["user_id"])
}

func TestLogger_LevelFilter(t *testing.T) {
	var buf bytes.Buffer
	logger, err := log.NewWithWriter(&buf, log.Config{Level: "warn"}, "s", "v")
	require.NoError(t, err)
	logger.Info("skip")
	assert.Empty(t, buf.String())
}

func TestNew_InvalidConfig(t *testing.T) {
	_, err := log.NewWithWriter(&bytes.Buffer{}, log.Config{Level: "loud"}, "s", "v")
	assert.Error(t, err)
	_, err = log.NewWithWriter(&bytes.Buffer{}, log.Config{Level: "info", Format: "xml"}, "s", "v")
	assert.Error(t, err)
}
