// Package requestid mang mã request (X-Request-Id) trong context để log, lỗi
// trả về client (UX §7.5: "mã tham chiếu") và các lớp khác cùng dùng.
package requestid

import "context"

// Header là tên header HTTP chứa mã request.
const Header = "X-Request-Id"

type ctxKey struct{}

// With gắn mã request vào context.
func With(ctx context.Context, id string) context.Context {
	return context.WithValue(ctx, ctxKey{}, id)
}

// From đọc mã request; chuỗi rỗng nếu không có.
func From(ctx context.Context) string {
	id, _ := ctx.Value(ctxKey{}).(string)
	return id
}
