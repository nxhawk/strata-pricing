package config_test

import (
	"errors"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/nxhawk/strata-pricing/internal/platform/config"
)

type inner struct {
	DSN      string `env:"DSN,required"`
	MaxConns int32  `env:"MAX_CONNS" envDefault:"20"`
}

type sample struct {
	PG      inner         `envPrefix:"PG_"`
	Timeout time.Duration `env:"TIMEOUT" envDefault:"8s"`
}

func (s *sample) Validate() error {
	if s.PG.MaxConns < 1 {
		return errors.New("PG_MAX_CONNS must be >= 1")
	}
	return nil
}

func TestLoad_NestedPrefixAndDefaults(t *testing.T) {
	t.Setenv("PG_DSN", "postgres://x")
	cfg, err := config.Load[sample]()
	require.NoError(t, err)
	assert.Equal(t, "postgres://x", cfg.PG.DSN)
	assert.Equal(t, int32(20), cfg.PG.MaxConns)
	assert.Equal(t, 8*time.Second, cfg.Timeout)
}

func TestLoad_MissingRequired(t *testing.T) {
	_, err := config.Load[sample]()
	require.Error(t, err)
	assert.Contains(t, err.Error(), "PG_DSN")
}

func TestLoad_RunsValidate(t *testing.T) {
	t.Setenv("PG_DSN", "postgres://x")
	t.Setenv("PG_MAX_CONNS", "0")
	_, err := config.Load[sample]()
	require.Error(t, err)
	assert.Contains(t, err.Error(), "PG_MAX_CONNS")
}
