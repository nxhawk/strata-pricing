// Package config nạp cấu hình từ biến môi trường (12-factor, SPEC §17.8).
//
// Mỗi service khai báo một struct Config với tag `env`; nạp một lần trong
// main, thiếu biến bắt buộc hoặc giá trị sai thì dừng ngay với lỗi rõ ràng.
//
// Quy ước tag (thư viện caarlos0/env, xem docs/deviations.md):
//
//	DSN      string `env:"DSN,required"`         // bắt buộc
//	MaxConns int32  `env:"MAX_CONNS" envDefault:"20"`
//	PG       postgres.Config `envPrefix:"PG_"`   // struct lồng -> PG_DSN, PG_MAX_CONNS
package config

import (
	"fmt"

	"github.com/caarlos0/env/v11"
)

// Validator được gọi sau khi nạp xong để kiểm tra ràng buộc giữa các trường.
type Validator interface {
	Validate() error
}

// Load nạp cấu hình vào T. Nếu *T có Validate() thì gọi luôn.
func Load[T any]() (T, error) {
	var cfg T
	if err := env.Parse(&cfg); err != nil {
		return cfg, fmt.Errorf("config: %w", err)
	}
	if v, ok := any(&cfg).(Validator); ok {
		if err := v.Validate(); err != nil {
			return cfg, fmt.Errorf("config: %w", err)
		}
	}
	return cfg, nil
}
