// Package admin dựng HTTP server quản trị nội bộ của mỗi service:
// /livez, /readyz, /metrics, /debug/pprof/*. Server này chỉ mở trong mạng nội bộ
// (không publish qua gateway) và không yêu cầu xác thực.
package admin

import (
	"net/http"
	"net/http/pprof"
	"time"

	"github.com/nxhawk/strata-pricing/internal/platform/health"
	"github.com/nxhawk/strata-pricing/internal/platform/metrics"
)

// NewServer tạo *http.Server cho cổng admin.
func NewServer(addr string, hr *health.Registry, mr *metrics.Registry) *http.Server {
	mux := http.NewServeMux()
	mux.Handle("GET /livez", health.LivezHandler())
	mux.Handle("GET /readyz", hr.ReadyzHandler())
	mux.Handle("GET /metrics", mr.Handler())
	mux.HandleFunc("/debug/pprof/", pprof.Index)
	mux.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	mux.HandleFunc("/debug/pprof/profile", pprof.Profile)
	mux.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
	mux.HandleFunc("/debug/pprof/trace", pprof.Trace)

	return &http.Server{
		Addr:              addr,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
		// pprof/profile mặc định lấy mẫu 30s nên WriteTimeout phải dài hơn.
		WriteTimeout: 60 * time.Second,
		IdleTimeout:  90 * time.Second,
	}
}
