// Package metrics cung cấp registry Prometheus và các metric dùng chung
// (ARCH §12.2, SPEC §19.1).
package metrics

import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/collectors"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// Registry gói registry riêng của service (không dùng registry toàn cục để
// test độc lập) và registerer đã gắn nhãn service.
type Registry struct {
	reg *prometheus.Registry
	// Registerer gắn sẵn nhãn service=<tên>; dùng để đăng ký metric nghiệp vụ.
	Registerer prometheus.Registerer
}

// NewRegistry tạo registry có sẵn collector Go runtime và process.
func NewRegistry(service string) *Registry {
	reg := prometheus.NewRegistry()
	reg.MustRegister(
		collectors.NewGoCollector(),
		collectors.NewProcessCollector(collectors.ProcessCollectorOpts{}),
	)
	return &Registry{
		reg:        reg,
		Registerer: prometheus.WrapRegistererWith(prometheus.Labels{"service": service}, reg),
	}
}

// Handler trả về endpoint /metrics.
func (r *Registry) Handler() http.Handler {
	return promhttp.HandlerFor(r.reg, promhttp.HandlerOpts{Registry: r.reg})
}

// Gatherer phục vụ test.
func (r *Registry) Gatherer() prometheus.Gatherer { return r.reg }

// HTTP là metric RED cho HTTP server.
type HTTP struct {
	Duration *prometheus.HistogramVec
	Requests *prometheus.CounterVec
}

// latencyBuckets bám theo NFR-01 (300ms) và NFR-02 (150ms / 400ms).
var latencyBuckets = []float64{.005, .01, .025, .05, .1, .15, .2, .3, .4, .6, 1, 2, 5, 10}

// NewHTTP đăng ký metric HTTP server.
func NewHTTP(r prometheus.Registerer) *HTTP {
	m := &HTTP{
		Duration: prometheus.NewHistogramVec(prometheus.HistogramOpts{
			Name:    "http_server_request_duration_seconds",
			Help:    "Thời gian xử lý HTTP request.",
			Buckets: latencyBuckets,
		}, []string{"route", "method", "code"}),
		Requests: prometheus.NewCounterVec(prometheus.CounterOpts{
			Name: "http_server_requests_total",
			Help: "Số HTTP request đã xử lý.",
		}, []string{"route", "method", "code"}),
	}
	r.MustRegister(m.Duration, m.Requests)
	return m
}
