// Package service là "bộ khung" chung cho mọi binary trong cmd/: nạp cấu hình,
// dựng logger, OpenTelemetry, metrics, health, cổng admin và vòng đời tắt êm.
//
// Mỗi cmd/<service>/main.go chỉ còn khai báo Config riêng và hàm setup nối dây
// các thành phần nghiệp vụ (composition root, ARCH §5.4):
//
//	func main() {
//		service.Main("query-svc", func(ctx context.Context, k *service.Kit, cfg Config) error {
//			k.AddHTTP("api", cfg.HTTPAddr, router)
//			return nil
//		})
//	}
package service

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/nxhawk/strata-pricing/internal/platform/admin"
	"github.com/nxhawk/strata-pricing/internal/platform/buildinfo"
	"github.com/nxhawk/strata-pricing/internal/platform/config"
	"github.com/nxhawk/strata-pricing/internal/platform/health"
	"github.com/nxhawk/strata-pricing/internal/platform/lifecycle"
	"github.com/nxhawk/strata-pricing/internal/platform/log"
	"github.com/nxhawk/strata-pricing/internal/platform/metrics"
	"github.com/nxhawk/strata-pricing/internal/platform/otelx"
)

// Base là phần cấu hình chung, nhúng (embed) vào Config của từng service.
type Base struct {
	Log       log.Config       `envPrefix:"LOG_"`
	Otel      otelx.Config     `envPrefix:"OTEL_"`
	Shutdown  lifecycle.Config `envPrefix:"SHUTDOWN_"`
	HTTPAddr  string           `env:"HTTP_ADDR" envDefault:":8080"`
	AdminAddr string           `env:"ADMIN_ADDR" envDefault:":8090"`
}

// BaseConfig cho phép Main đọc phần chung từ Config bất kỳ có nhúng Base.
func (b Base) BaseConfig() Base { return b }

// Configurer là ràng buộc kiểu cho Config của service.
type Configurer interface{ BaseConfig() Base }

// Kit là các dịch vụ nền đã dựng sẵn, truyền cho hàm setup.
type Kit struct {
	Name    string
	Version string
	Log     *slog.Logger
	Health  *health.Registry
	Metrics *metrics.Registry
	runner  *lifecycle.Runner
}

// Add thêm một thành phần chạy dài hạn.
func (k *Kit) Add(c lifecycle.Component) { k.runner.Add(c) }

// OnStop đăng ký hook dọn dẹp (đóng pool, client...).
func (k *Kit) OnStop(fns ...func(context.Context) error) { k.runner.OnStop(fns...) }

// AddHTTP thêm HTTP server công khai với timeout chuẩn ARCH §5.4 / §10.1.
func (k *Kit) AddHTTP(name, addr string, h http.Handler) error {
	srv := &http.Server{
		Addr:              addr,
		Handler:           h,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      35 * time.Second,
		IdleTimeout:       90 * time.Second,
		ErrorLog:          slog.NewLogLogger(k.Log.Handler(), slog.LevelWarn),
	}
	c, err := lifecycle.NewHTTPServer(name, srv)
	if err != nil {
		return err
	}
	k.Add(c)
	k.Log.Info("http server listening", "server", name, "addr", c.Addr())
	return nil
}

// SetupFunc nối dây phần riêng của service. ctx bị huỷ khi service bắt đầu tắt.
type SetupFunc[C Configurer] func(ctx context.Context, k *Kit, cfg C) error

// Main là điểm vào chuẩn của mọi service; không bao giờ trả về.
func Main[C Configurer](name string, setup SetupFunc[C]) {
	os.Exit(run(name, setup))
}

func run[C Configurer](name string, setup SetupFunc[C]) int {
	cfg, err := config.Load[C]()
	if err != nil {
		fmt.Fprintf(os.Stderr, "%s: %v\n", name, err)
		return 2
	}
	base := cfg.BaseConfig()

	// "<binary> healthcheck": dùng cho HEALTHCHECK của container distroless.
	if len(os.Args) > 1 && os.Args[1] == "healthcheck" {
		return probe(base.AdminAddr)
	}

	version := buildinfo.Version()
	logger, err := log.New(base.Log, name, version)
	if err != nil {
		fmt.Fprintf(os.Stderr, "%s: %v\n", name, err)
		return 2
	}
	slog.SetDefault(logger)

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM, syscall.SIGINT)
	defer stop()

	shutdownOtel, err := otelx.Init(ctx, base.Otel, name, version)
	if err != nil {
		logger.Error("init tracing", "err", err)
		return 1
	}

	kit := &Kit{
		Name:    name,
		Version: version,
		Log:     logger,
		Health:  health.NewRegistry(),
		Metrics: metrics.NewRegistry(name),
	}
	kit.runner = lifecycle.New(base.Shutdown, logger, kit.Health)
	kit.OnStop(func(c context.Context) error { return shutdownOtel(c) })

	adminSrv, err := lifecycle.NewHTTPServer("admin", admin.NewServer(base.AdminAddr, kit.Health, kit.Metrics))
	if err != nil {
		logger.Error("start admin server", "err", err)
		return 1
	}
	kit.Add(adminSrv)

	if err := setup(ctx, kit, cfg); err != nil {
		logger.Error("setup failed", "err", err)
		actx, cancel := context.WithTimeout(context.Background(), base.Shutdown.StopTimeout)
		defer cancel()
		kit.runner.Abort(actx) // giải phóng tài nguyên đã mở trước khi lỗi
		return 1
	}

	logger.Info("service starting", "admin_addr", adminSrv.Addr())
	if err := kit.runner.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
		logger.Error("service exited with error", "err", err)
		return 1
	}
	return 0
}
