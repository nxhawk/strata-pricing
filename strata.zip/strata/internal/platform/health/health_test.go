package health_test

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"

	"github.com/nxhawk/strata-pricing/internal/platform/health"
)

func TestReadyz_NotReadyUntilSet(t *testing.T) {
	reg := health.NewRegistry()
	rec := httptest.NewRecorder()
	reg.ReadyzHandler().ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/readyz", nil))
	assert.Equal(t, http.StatusServiceUnavailable, rec.Code)

	reg.SetReady(true)
	rec = httptest.NewRecorder()
	reg.ReadyzHandler().ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/readyz", nil))
	assert.Equal(t, http.StatusOK, rec.Code)
}

func TestReadyz_FailingCheck(t *testing.T) {
	reg := health.NewRegistry()
	reg.SetReady(true)
	reg.AddCheck("postgres", time.Second, func(context.Context) error { return errors.New("down") })
	reg.AddCheck("es", time.Second, func(context.Context) error { return nil })

	rep := reg.Check(context.Background())
	assert.Equal(t, "unavailable", rep.Status)
	assert.Equal(t, "down", rep.Checks["postgres"])
	assert.Equal(t, "ok", rep.Checks["es"])
}

func TestReadyz_CheckTimeout(t *testing.T) {
	reg := health.NewRegistry()
	reg.SetReady(true)
	reg.AddCheck("slow", 10*time.Millisecond, func(ctx context.Context) error {
		<-ctx.Done()
		return ctx.Err()
	})
	assert.Equal(t, "unavailable", reg.Check(context.Background()).Status)
}

func TestHTTPCheck(t *testing.T) {
	ok := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {}))
	defer ok.Close()
	bad := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(500) }))
	defer bad.Close()

	assert.NoError(t, health.HTTPCheck(ok.Client(), ok.URL)(context.Background()))
	assert.Error(t, health.HTTPCheck(bad.Client(), bad.URL)(context.Background()))
}
