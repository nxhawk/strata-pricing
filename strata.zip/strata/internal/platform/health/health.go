// Package health quản lý liveness / readiness (ARCH §10.5).
//
//   - /livez: process còn sống, không phụ thuộc hạ tầng ngoài.
//   - /readyz: sẵn sàng nhận việc = chưa vào shutdown và mọi check bắt buộc đều qua.
//
// Không đưa Keycloak vào readiness: token cũ + JWKS cache vẫn dùng được khi
// Keycloak gián đoạn (ARCH §10.6).
package health

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"sync"
	"sync/atomic"
	"time"
)

// CheckFunc kiểm tra một phụ thuộc; trả lỗi nếu chưa sẵn sàng.
type CheckFunc func(ctx context.Context) error

type check struct {
	fn      CheckFunc
	timeout time.Duration
}

// Registry lưu trạng thái ready và danh sách check.
type Registry struct {
	ready  atomic.Bool
	mu     sync.RWMutex
	checks map[string]check
}

// NewRegistry tạo registry ở trạng thái chưa ready.
func NewRegistry() *Registry { return &Registry{checks: map[string]check{}} }

// SetReady bật/tắt readiness (tắt ngay khi nhận SIGTERM).
func (r *Registry) SetReady(v bool) { r.ready.Store(v) }

// AddCheck đăng ký một check bắt buộc cho readiness.
func (r *Registry) AddCheck(name string, timeout time.Duration, fn CheckFunc) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.checks[name] = check{fn: fn, timeout: timeout}
}

// Report là kết quả readiness trả về dạng JSON.
type Report struct {
	Status string            `json:"status"` // "ok" | "unavailable"
	Checks map[string]string `json:"checks,omitempty"`
}

// Check chạy mọi check song song.
func (r *Registry) Check(ctx context.Context) Report {
	if !r.ready.Load() {
		return Report{Status: "unavailable", Checks: map[string]string{"lifecycle": "not ready"}}
	}
	r.mu.RLock()
	names := make([]string, 0, len(r.checks))
	for n := range r.checks {
		names = append(names, n)
	}
	sort.Strings(names)
	checks := make([]check, len(names))
	for i, n := range names {
		checks[i] = r.checks[n]
	}
	r.mu.RUnlock()

	results := make([]string, len(names))
	var wg sync.WaitGroup
	for i := range checks {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			cctx, cancel := context.WithTimeout(ctx, checks[i].timeout)
			defer cancel()
			if err := checks[i].fn(cctx); err != nil {
				results[i] = err.Error()
				return
			}
			results[i] = "ok"
		}(i)
	}
	wg.Wait()

	rep := Report{Status: "ok", Checks: make(map[string]string, len(names))}
	for i, n := range names {
		rep.Checks[n] = results[i]
		if results[i] != "ok" {
			rep.Status = "unavailable"
		}
	}
	return rep
}

// LivezHandler luôn trả 200 khi process còn phục vụ được HTTP.
func LivezHandler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		writeJSON(w, http.StatusOK, Report{Status: "ok"})
	})
}

// ReadyzHandler trả 200 khi ready, 503 nếu không.
func (r *Registry) ReadyzHandler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		rep := r.Check(req.Context())
		code := http.StatusOK
		if rep.Status != "ok" {
			code = http.StatusServiceUnavailable
		}
		writeJSON(w, code, rep)
	})
}

// HTTPCheck tạo check gọi GET url và chờ status 2xx (dùng cho ES, Connect...).
func HTTPCheck(client *http.Client, url string) CheckFunc {
	return func(ctx context.Context) error {
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
		if err != nil {
			return err
		}
		resp, err := client.Do(req)
		if err != nil {
			return err
		}
		defer resp.Body.Close()
		if resp.StatusCode/100 != 2 {
			return fmt.Errorf("status %d", resp.StatusCode)
		}
		return nil
	}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}
