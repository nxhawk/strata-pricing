// Package otelx khởi tạo OpenTelemetry tracing (NFR-15, SPEC §19.2).
//
// TracerProvider luôn được dựng - kể cả khi không có collector - để mọi request
// có trace_id trong log. Exporter OTLP/HTTP chỉ bật khi đặt
// OTEL_EXPORTER_OTLP_ENDPOINT (ví dụ http://jaeger:4318 khi chạy docker-compose).
package otelx

import (
	"context"
	"errors"
	"fmt"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/propagation"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
)

// Config cho tracing. Tên biến theo chuẩn OpenTelemetry để exporter tự đọc
// thêm các biến OTEL_EXPORTER_OTLP_* khác nếu cần.
type Config struct {
	Endpoint    string  `env:"EXPORTER_OTLP_ENDPOINT"`
	SampleRatio float64 `env:"TRACES_SAMPLER_RATIO" envDefault:"1"`
}

// ShutdownFunc flush span còn lại và giải phóng exporter.
type ShutdownFunc func(context.Context) error

// Init cài TracerProvider và propagator W3C (traceparent, baggage) toàn cục.
func Init(ctx context.Context, cfg Config, service, version string) (ShutdownFunc, error) {
	if cfg.SampleRatio < 0 || cfg.SampleRatio > 1 {
		return nil, errors.New("otelx: OTEL_TRACES_SAMPLER_RATIO must be in [0,1]")
	}
	res, err := resource.New(ctx,
		resource.WithFromEnv(),
		resource.WithAttributes(
			attribute.String("service.name", service),
			attribute.String("service.version", version),
		),
	)
	if err != nil {
		return nil, fmt.Errorf("otelx: resource: %w", err)
	}

	opts := []sdktrace.TracerProviderOption{
		sdktrace.WithResource(res),
		sdktrace.WithSampler(sdktrace.ParentBased(sdktrace.TraceIDRatioBased(cfg.SampleRatio))),
	}
	if cfg.Endpoint != "" {
		// Exporter tự đọc OTEL_EXPORTER_OTLP_ENDPOINT và nối thêm /v1/traces.
		exp, err := otlptracehttp.New(ctx)
		if err != nil {
			return nil, fmt.Errorf("otelx: exporter: %w", err)
		}
		opts = append(opts, sdktrace.WithBatcher(exp))
	}

	tp := sdktrace.NewTracerProvider(opts...)
	otel.SetTracerProvider(tp)
	otel.SetTextMapPropagator(propagation.NewCompositeTextMapPropagator(
		propagation.TraceContext{}, propagation.Baggage{},
	))
	return tp.Shutdown, nil
}
