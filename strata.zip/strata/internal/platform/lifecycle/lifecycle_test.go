package lifecycle_test

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/nxhawk/strata-pricing/internal/platform/lifecycle"
)

type readyFlag struct{ atomic.Bool }

func (r *readyFlag) SetReady(v bool) { r.Store(v) }

type fakeComponent struct {
	name    string
	failErr error
	stopped chan struct{}
	order   *[]string
	mu      *sync.Mutex
}

func (f *fakeComponent) Name() string { return f.name }
func (f *fakeComponent) Start(ctx context.Context) error {
	if f.failErr != nil {
		return f.failErr
	}
	select {
	case <-ctx.Done():
	case <-f.stopped:
	}
	return nil
}
func (f *fakeComponent) Stop(context.Context) error {
	f.mu.Lock()
	*f.order = append(*f.order, f.name)
	f.mu.Unlock()
	close(f.stopped)
	return nil
}

func newRunner(ready *readyFlag) *lifecycle.Runner {
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	return lifecycle.New(lifecycle.Config{StopTimeout: time.Second}, logger, ready)
}

func TestRunner_StopsInReverseOrderAndRunsHooks(t *testing.T) {
	var order []string
	var mu sync.Mutex
	ready := &readyFlag{}
	r := newRunner(ready)
	for _, n := range []string{"a", "b", "c"} {
		r.Add(&fakeComponent{name: n, stopped: make(chan struct{}), order: &order, mu: &mu})
	}
	hookRan := false
	r.OnStop(func(context.Context) error { hookRan = true; return nil })

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error)
	go func() { done <- r.Run(ctx) }()

	require.Eventually(t, ready.Load, time.Second, 5*time.Millisecond)
	cancel()
	require.NoError(t, <-done)

	assert.False(t, ready.Load())
	assert.Equal(t, []string{"c", "b", "a"}, order)
	assert.True(t, hookRan)
}

func TestRunner_ComponentFailureStopsOthers(t *testing.T) {
	var order []string
	var mu sync.Mutex
	r := newRunner(&readyFlag{})
	r.Add(&fakeComponent{name: "ok", stopped: make(chan struct{}), order: &order, mu: &mu})
	r.Add(&fakeComponent{name: "bad", failErr: errors.New("boom"), stopped: make(chan struct{}), order: &order, mu: &mu})

	err := r.Run(context.Background())
	require.Error(t, err)
	assert.Contains(t, err.Error(), "boom")
	assert.Contains(t, order, "ok")
}

func TestHTTPServer_ServesAndShutsDown(t *testing.T) {
	srv := &http.Server{Addr: "127.0.0.1:0", Handler: http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte("pong"))
	}), ReadHeaderTimeout: time.Second}
	c, err := lifecycle.NewHTTPServer("api", srv)
	require.NoError(t, err)

	r := newRunner(&readyFlag{})
	r.Add(c)
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error)
	go func() { done <- r.Run(ctx) }()

	require.Eventually(t, func() bool {
		resp, err := http.Get("http://" + c.Addr())
		if err != nil {
			return false
		}
		defer resp.Body.Close()
		b, _ := io.ReadAll(resp.Body)
		return string(b) == "pong"
	}, time.Second, 10*time.Millisecond)

	cancel()
	require.NoError(t, <-done)
}

func TestNewHTTPServer_PortInUse(t *testing.T) {
	first, err := lifecycle.NewHTTPServer("a", &http.Server{Addr: "127.0.0.1:0", ReadHeaderTimeout: time.Second})
	require.NoError(t, err)
	_, err = lifecycle.NewHTTPServer("b", &http.Server{Addr: first.Addr(), ReadHeaderTimeout: time.Second})
	assert.Error(t, err)
}
