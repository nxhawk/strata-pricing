package lifecycle

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
)

// HTTPServer bọc *http.Server thành Component. Listener được mở ngay khi tạo
// để lỗi cổng bận lộ ra trước khi service báo ready.
type HTTPServer struct {
	name string
	srv  *http.Server
	ln   net.Listener
}

// NewHTTPServer mở listener tại srv.Addr.
func NewHTTPServer(name string, srv *http.Server) (*HTTPServer, error) {
	ln, err := net.Listen("tcp", srv.Addr)
	if err != nil {
		return nil, fmt.Errorf("listen %s (%s): %w", name, srv.Addr, err)
	}
	return &HTTPServer{name: name, srv: srv, ln: ln}, nil
}

func (h *HTTPServer) Name() string { return h.name }

// Addr trả về địa chỉ thực đang lắng nghe (hữu ích khi dùng cổng :0 trong test).
func (h *HTTPServer) Addr() string { return h.ln.Addr().String() }

func (h *HTTPServer) Start(context.Context) error {
	if err := h.srv.Serve(h.ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
		return err
	}
	return nil
}

func (h *HTTPServer) Stop(ctx context.Context) error { return h.srv.Shutdown(ctx) }
