// Package lifecycle chạy các thành phần dài hạn của một service (HTTP server,
// consumer, scheduler) và tắt êm theo ARCH §10.5:
//
//  1. Nhận SIGTERM (hoặc một thành phần lỗi) -> readiness = false.
//  2. Chờ PreStopDelay để load balancer ngừng gửi request mới.
//  3. Dừng các thành phần theo thứ tự ngược lúc khởi động, trong StopTimeout.
//  4. Chạy các hook OnStop (đóng pool DB, flush OTel...) theo thứ tự ngược.
package lifecycle

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"golang.org/x/sync/errgroup"
)

// Config thời gian tắt (biến SHUTDOWN_PRESTOP_DELAY, SHUTDOWN_TIMEOUT).
type Config struct {
	PreStopDelay time.Duration `env:"PRESTOP_DELAY" envDefault:"5s"`
	StopTimeout  time.Duration `env:"TIMEOUT" envDefault:"35s"`
}

// Component là một thành phần chạy dài hạn.
//
// Start chặn cho tới khi thành phần dừng; trả nil khi dừng bình thường (sau
// Stop hoặc khi ctx bị huỷ). Stop yêu cầu dừng và chờ tối đa tới hạn của ctx.
type Component interface {
	Name() string
	Start(ctx context.Context) error
	Stop(ctx context.Context) error
}

// ReadinessSetter được Runner gọi khi bắt đầu/kết thúc phục vụ.
type ReadinessSetter interface{ SetReady(bool) }

// Runner điều phối các Component.
type Runner struct {
	cfg        Config
	log        *slog.Logger
	ready      ReadinessSetter
	components []Component
	onStop     []func(context.Context) error
}

// New tạo Runner.
func New(cfg Config, log *slog.Logger, ready ReadinessSetter) *Runner {
	return &Runner{cfg: cfg, log: log, ready: ready}
}

// Add thêm thành phần; thứ tự thêm là thứ tự khởi động.
func (r *Runner) Add(c Component) { r.components = append(r.components, c) }

// OnStop đăng ký hook dọn dẹp, chạy sau khi mọi thành phần đã dừng.
func (r *Runner) OnStop(fns ...func(context.Context) error) { r.onStop = append(r.onStop, fns...) }

// Run khởi động mọi thành phần và chặn tới khi ctx bị huỷ hoặc một thành phần lỗi.
func (r *Runner) Run(ctx context.Context) error {
	g, gctx := errgroup.WithContext(ctx)
	for _, c := range r.components {
		g.Go(func() error {
			r.log.InfoContext(gctx, "component started", "component", c.Name())
			if err := c.Start(gctx); err != nil {
				return fmt.Errorf("%s: %w", c.Name(), err)
			}
			return nil
		})
	}
	r.ready.SetReady(true)

	<-gctx.Done() // tín hiệu dừng hoặc một thành phần lỗi
	r.ready.SetReady(false)
	r.log.Info("shutting down", "prestop_delay", r.cfg.PreStopDelay.String())
	sleep(r.cfg.PreStopDelay)

	// ctx đã bị huỷ (SIGTERM) nhưng vẫn cần thời gian để dừng: bỏ cancel, giữ value.
	sctx, cancel := context.WithTimeout(context.WithoutCancel(ctx), r.cfg.StopTimeout)
	defer cancel()

	var errs []error
	for i := len(r.components) - 1; i >= 0; i-- {
		c := r.components[i]
		if err := c.Stop(sctx); err != nil {
			r.log.Warn("component stop failed", "component", c.Name(), "err", err)
			errs = append(errs, fmt.Errorf("stop %s: %w", c.Name(), err))
		}
	}
	runErr := g.Wait()
	for i := len(r.onStop) - 1; i >= 0; i-- {
		if err := r.onStop[i](sctx); err != nil {
			r.log.Warn("on-stop hook failed", "err", err)
			errs = append(errs, err)
		}
	}
	r.log.Info("stopped")
	return errors.Join(append([]error{runErr}, errs...)...)
}

// Abort chạy các hook OnStop mà không khởi động thành phần nào; dùng khi
// service lỗi trong lúc nối dây để giải phóng tài nguyên đã mở.
func (r *Runner) Abort(ctx context.Context) {
	for i := len(r.onStop) - 1; i >= 0; i-- {
		if err := r.onStop[i](ctx); err != nil {
			r.log.Warn("on-stop hook failed", "err", err)
		}
	}
}

// sleep chờ đủ d. Không dùng ctx vì lúc này ctx gốc đã bị huỷ (SIGTERM) mà vẫn
// phải chờ - đó chính là mục đích của prestop delay.
func sleep(d time.Duration) {
	if d <= 0 {
		return
	}
	t := time.NewTimer(d)
	defer t.Stop()
	<-t.C
}
