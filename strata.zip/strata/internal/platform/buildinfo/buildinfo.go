// Package buildinfo cung cấp phiên bản build, gắn qua -ldflags:
//
//	go build -ldflags "-X github.com/nxhawk/strata-pricing/internal/platform/buildinfo.version=1.0.0"
package buildinfo

import "runtime/debug"

var version = "" // ghi đè bằng -ldflags

// Version trả về phiên bản: giá trị ldflags, nếu không có thì commit VCS rút gọn,
// cuối cùng là "dev".
func Version() string {
	if version != "" {
		return version
	}
	if bi, ok := debug.ReadBuildInfo(); ok {
		for _, s := range bi.Settings {
			if s.Key == "vcs.revision" && len(s.Value) >= 7 {
				return s.Value[:7]
			}
		}
	}
	return "dev"
}
