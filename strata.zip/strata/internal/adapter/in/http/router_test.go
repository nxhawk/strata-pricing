package httpin_test

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/go-chi/chi/v5"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/testutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/propagation"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"

	httpin "github.com/nxhawk/strata-pricing/internal/adapter/in/http"
	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/middleware"
	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
	"github.com/nxhawk/strata-pricing/internal/domain/identity"
	"github.com/nxhawk/strata-pricing/internal/platform/log"
	"github.com/nxhawk/strata-pricing/internal/platform/metrics"
)

type fakeVerifier map[string]identity.Actor

func (f fakeVerifier) Verify(_ context.Context, raw string) (identity.Actor, error) {
	if a, ok := f[raw]; ok {
		return a, nil
	}
	return identity.Actor{}, apperr.Unauthenticated("invalid token", nil)
}

type env struct {
	h       http.Handler
	logs    *bytes.Buffer
	metrics *metrics.HTTP
}

func newEnv(t *testing.T) env {
	t.Helper()
	otel.SetTracerProvider(sdktrace.NewTracerProvider())
	otel.SetTextMapPropagator(propagation.TraceContext{})
	var buf bytes.Buffer
	logger, err := log.NewWithWriter(&buf, log.Config{Level: "debug"}, "test-svc", "t")
	require.NoError(t, err)
	m := metrics.NewHTTP(prometheus.NewRegistry())

	viewer := identity.NewActor("u-viewer", "viewer", "Viewer", "", identity.KindUser, []string{"VIEWER"}, []string{"*"})
	h := httpin.NewRouter(httpin.Deps{
		Logger:   logger,
		Metrics:  m,
		Verifier: fakeVerifier{"good": viewer},
	}, "/api/v1/test", func(r chi.Router) {
		r.Get("/ok", func(w http.ResponseWriter, _ *http.Request) { httpin.WriteJSON(w, 200, map[string]bool{"ok": true}) })
		r.Get("/panic", func(http.ResponseWriter, *http.Request) { panic("boom") })
		r.With(middleware.RequirePermission(identity.PermAdminManage)).
			Get("/admin", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(204) })
	})
	return env{h: h, logs: &buf, metrics: m}
}

func (e env) do(method, path, token string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, path, nil)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	e.h.ServeHTTP(rec, req)
	return rec
}

func lastLog(t *testing.T, buf *bytes.Buffer) map[string]any {
	t.Helper()
	lines := strings.Split(strings.TrimSpace(buf.String()), "\n")
	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(lines[len(lines)-1]), &m))
	return m
}

func TestRouter_RequiresBearerToken(t *testing.T) {
	e := newEnv(t)
	for _, tok := range []string{"", "bad"} {
		rec := e.do(http.MethodGet, "/api/v1/test/ok", tok)
		assert.Equal(t, http.StatusUnauthorized, rec.Code)
		assert.Equal(t, "application/problem+json", rec.Header().Get("Content-Type"))
		assert.Contains(t, rec.Body.String(), `"code":"UNAUTHENTICATED"`)
	}
}

func TestRouter_AccessLogIsJSONWithTraceAndUser(t *testing.T) {
	e := newEnv(t)
	rec := e.do(http.MethodGet, "/api/v1/test/ok", "good")
	require.Equal(t, http.StatusOK, rec.Code)
	reqID := rec.Header().Get("X-Request-Id")
	require.NotEmpty(t, reqID)

	entry := lastLog(t, e.logs)
	assert.Equal(t, "http request", entry["msg"])
	assert.Equal(t, "/api/v1/test/ok", entry["route"])
	assert.EqualValues(t, 200, entry["status"])
	assert.Equal(t, reqID, entry["request_id"])
	assert.Equal(t, "u-viewer", entry["user_id"])
	assert.Len(t, entry["trace_id"], 32)
	assert.Len(t, entry["span_id"], 16)
}

func TestRouter_PropagatesIncomingTraceparent(t *testing.T) {
	e := newEnv(t)
	req := httptest.NewRequest(http.MethodGet, "/api/v1/test/ok", nil)
	req.Header.Set("Authorization", "Bearer good")
	req.Header.Set("traceparent", "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01")
	e.h.ServeHTTP(httptest.NewRecorder(), req)

	assert.Equal(t, "4bf92f3577b34da6a3ce929d0e0e4736", lastLog(t, e.logs)["trace_id"])
}

func TestRouter_KeepsValidIncomingRequestID(t *testing.T) {
	e := newEnv(t)
	req := httptest.NewRequest(http.MethodGet, "/api/v1/test/ok", nil)
	req.Header.Set("Authorization", "Bearer good")
	req.Header.Set("X-Request-Id", "abc-123")
	rec := httptest.NewRecorder()
	e.h.ServeHTTP(rec, req)
	assert.Equal(t, "abc-123", rec.Header().Get("X-Request-Id"))

	req.Header.Set("X-Request-Id", "bad\nvalue")
	rec = httptest.NewRecorder()
	e.h.ServeHTTP(rec, req)
	assert.NotEqual(t, "bad\nvalue", rec.Header().Get("X-Request-Id"))
}

func TestRouter_PanicBecomes500Problem(t *testing.T) {
	e := newEnv(t)
	rec := e.do(http.MethodGet, "/api/v1/test/panic", "good")
	assert.Equal(t, http.StatusInternalServerError, rec.Code)
	assert.Contains(t, rec.Body.String(), `"code":"INTERNAL"`)
	assert.NotContains(t, rec.Body.String(), "boom")

	entry := lastLog(t, e.logs)
	assert.Equal(t, "ERROR", entry["level"])
	assert.EqualValues(t, 500, entry["status"])
}

func TestRouter_RequirePermission(t *testing.T) {
	e := newEnv(t)
	rec := e.do(http.MethodGet, "/api/v1/test/admin", "good")
	assert.Equal(t, http.StatusForbidden, rec.Code)
	assert.Contains(t, rec.Body.String(), `"code":"FORBIDDEN"`)
}

func TestRouter_NotFoundIsProblemAndMetricLabelBounded(t *testing.T) {
	e := newEnv(t)
	rec := e.do(http.MethodGet, "/does/not/exist", "")
	assert.Equal(t, http.StatusNotFound, rec.Code)
	assert.Contains(t, rec.Body.String(), `"code":"NOT_FOUND"`)
	assert.InDelta(t, 1, testutil.ToFloat64(e.metrics.Requests.WithLabelValues("unmatched", "GET", "404")), 0)
}
