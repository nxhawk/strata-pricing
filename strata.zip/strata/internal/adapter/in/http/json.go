package httpin

import (
	"encoding/json"
	"net/http"
)

// WriteJSON ghi v dạng JSON UTF-8 với status code.
func WriteJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
