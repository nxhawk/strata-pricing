package middleware

import (
	"context"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"github.com/nxhawk/strata-pricing/internal/platform/metrics"
)

// unmatchedRoute là nhãn route cho request không khớp route nào (404),
// tránh đưa path tuỳ ý vào nhãn metric.
const unmatchedRoute = "unmatched"

// Observe ghi access log JSON và metric RED cho mỗi request.
//
// Mức log: 5xx -> ERROR; còn lại (kể cả 4xx nghiệp vụ dự kiến) -> INFO, để
// cảnh báo lỗi không bị nhiễu (ARCH §12.4).
func Observe(logger *slog.Logger, m *metrics.HTTP) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			start := time.Now()
			sw := newStatusWriter(w)
			info := &requestInfo{}
			ctx := context.WithValue(r.Context(), requestInfoKey{}, info)
			req := r.WithContext(ctx)
			next.ServeHTTP(sw, req)
			elapsed := time.Since(start)

			route := routePattern(req)
			if route == "" {
				route = unmatchedRoute
			}
			code := strconv.Itoa(sw.Status())
			if m != nil {
				m.Duration.WithLabelValues(route, r.Method, code).Observe(elapsed.Seconds())
				m.Requests.WithLabelValues(route, r.Method, code).Inc()
			}

			level := slog.LevelInfo
			if sw.Status() >= 500 {
				level = slog.LevelError
			}
			attrs := []any{
				"method", r.Method,
				"route", route,
				"path", r.URL.Path,
				"status", sw.Status(),
				"bytes", sw.bytes,
				"duration_ms", float64(elapsed.Microseconds()) / 1000,
			}
			if info.userID != "" {
				attrs = append(attrs, "user_id", info.userID)
			}
			logger.Log(ctx, level, "http request", attrs...)
		})
	}
}

// requestInfo cho phép middleware bên trong (Authenticate) báo ngược thông tin
// lên access log bên ngoài, vì context chỉ truyền xuôi.
type requestInfo struct{ userID string }

type requestInfoKey struct{}

func setRequestUser(ctx context.Context, userID string) {
	if info, ok := ctx.Value(requestInfoKey{}).(*requestInfo); ok {
		info.userID = userID
	}
}
