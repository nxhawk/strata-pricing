package middleware

import "net/http"

// statusWriter ghi nhận status code và số byte đã ghi. Unwrap giúp
// http.ResponseController (Flush, SetDeadline...) vẫn hoạt động qua lớp bọc.
type statusWriter struct {
	http.ResponseWriter
	status int
	bytes  int
}

func newStatusWriter(w http.ResponseWriter) *statusWriter {
	if sw, ok := w.(*statusWriter); ok {
		return sw
	}
	return &statusWriter{ResponseWriter: w}
}

func (w *statusWriter) WriteHeader(code int) {
	if w.status == 0 {
		w.status = code
	}
	w.ResponseWriter.WriteHeader(code)
}

func (w *statusWriter) Write(b []byte) (int, error) {
	if w.status == 0 {
		w.status = http.StatusOK
	}
	n, err := w.ResponseWriter.Write(b)
	w.bytes += n
	return n, err
}

// Status trả về status đã ghi (200 nếu handler không ghi gì).
func (w *statusWriter) Status() int {
	if w.status == 0 {
		return http.StatusOK
	}
	return w.status
}

func (w *statusWriter) Unwrap() http.ResponseWriter { return w.ResponseWriter }
