package middleware

import (
	"fmt"
	"net/http"

	"github.com/go-chi/chi/v5"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/propagation"
	"go.opentelemetry.io/otel/trace"
)

const tracerName = "github.com/nxhawk/strata-pricing/internal/adapter/in/http"

// Tracing tạo span server cho mỗi request, tiếp nối traceparent (W3C) từ client.
// Tên span được đặt theo route pattern sau khi chi định tuyến xong
// (ví dụ "GET /api/v1/query/me") để không bùng nổ cardinality.
func Tracing(next http.Handler) http.Handler {
	tracer := otel.Tracer(tracerName)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctx := otel.GetTextMapPropagator().Extract(r.Context(), propagation.HeaderCarrier(r.Header))
		ctx, span := tracer.Start(ctx, "HTTP "+r.Method,
			trace.WithSpanKind(trace.SpanKindServer),
			trace.WithAttributes(
				attribute.String("http.request.method", r.Method),
				attribute.String("url.path", r.URL.Path),
			),
		)
		defer span.End()

		sw := newStatusWriter(w)
		next.ServeHTTP(sw, r.WithContext(ctx))

		if route := routePattern(r); route != "" {
			span.SetName(r.Method + " " + route)
			span.SetAttributes(attribute.String("http.route", route))
		}
		span.SetAttributes(attribute.Int("http.response.status_code", sw.Status()))
		if sw.Status() >= 500 {
			span.SetStatus(codes.Error, fmt.Sprintf("HTTP %d", sw.Status()))
		}
	})
}

// routePattern trả về pattern chi đã khớp, rỗng nếu không khớp route nào.
func routePattern(r *http.Request) string {
	if rc := chi.RouteContext(r.Context()); rc != nil {
		return rc.RoutePattern()
	}
	return ""
}
