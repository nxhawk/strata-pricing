package middleware

import (
	"context"
	"net/http"
	"time"
)

// Timeout gắn deadline vào context của request (ARCH §10.1: handler 6s cho
// command/query thường). Mọi I/O (pgx, ES, S3) đều tôn trọng ctx nên sẽ dừng
// khi hết hạn và problem.Write trả 503 UNAVAILABLE. WriteTimeout của
// http.Server là chốt chặn cuối.
func Timeout(d time.Duration) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if d <= 0 {
				next.ServeHTTP(w, r)
				return
			}
			ctx, cancel := context.WithTimeout(r.Context(), d)
			defer cancel()
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// BodyLimit giới hạn kích thước body (ARCH §6.1: 1MB JSON, 50MB multipart).
// Vượt giới hạn -> lỗi *http.MaxBytesError khi đọc body -> 413.
func BodyLimit(maxBytes int64) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.Body != nil && maxBytes > 0 {
				r.Body = http.MaxBytesReader(w, r.Body, maxBytes)
			}
			next.ServeHTTP(w, r)
		})
	}
}
