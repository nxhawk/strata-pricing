package middleware

import (
	"net/http"
	"strings"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"

	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/problem"
	"github.com/nxhawk/strata-pricing/internal/app/port"
	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
	"github.com/nxhawk/strata-pricing/internal/domain/identity"
	"github.com/nxhawk/strata-pricing/internal/platform/log"
)

// Authenticate xác thực Bearer JWT bằng verifier và gắn Actor vào context.
//
// Service luôn tự kiểm tra token, không tin header từ gateway (ARCH §11.1,
// FLOW Luồng 1: "Gateway kiểm tra JWT và service kiểm tra lại").
func Authenticate(v port.TokenVerifier) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			raw, ok := bearerToken(r.Header.Get("Authorization"))
			if !ok {
				problem.Write(w, r, apperr.Unauthenticated("Thiếu access token", nil))
				return
			}
			actor, err := v.Verify(r.Context(), raw)
			if err != nil {
				problem.Write(w, r, err)
				return
			}
			setRequestUser(r.Context(), actor.ID)
			ctx := identity.WithActor(r.Context(), actor)
			ctx = log.WithAttrs(ctx, "user_id", actor.ID)
			trace.SpanFromContext(ctx).SetAttributes(attribute.String("enduser.id", actor.ID))
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// RequirePermission chặn request nếu actor thiếu quyền (kiểm tra mức route,
// ARCH §6.1 bước 9). Kiểm tra supplier scope thuộc application layer.
func RequirePermission(p identity.Permission) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			actor, ok := identity.FromContext(r.Context())
			if !ok {
				problem.Write(w, r, apperr.Unauthenticated("Chưa xác thực", nil))
				return
			}
			if !actor.Can(p) {
				problem.Write(w, r, apperr.Forbidden(apperr.CodeForbidden, "Bạn không có quyền thực hiện thao tác này"))
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

func bearerToken(h string) (string, bool) {
	const prefix = "bearer "
	if len(h) <= len(prefix) || !strings.EqualFold(h[:len(prefix)], prefix) {
		return "", false
	}
	tok := strings.TrimSpace(h[len(prefix):])
	return tok, tok != ""
}
