// Package middleware chứa middleware HTTP dùng chung cho command-svc và
// query-svc. Thứ tự lắp ráp xem httpin.NewRouter.
package middleware

import (
	"net/http"

	"github.com/google/uuid"

	"github.com/nxhawk/strata-pricing/internal/platform/log"
	"github.com/nxhawk/strata-pricing/internal/platform/requestid"
)

const maxRequestIDLen = 64

// RequestID nhận X-Request-Id hợp lệ từ client/gateway hoặc sinh UUIDv7,
// gắn vào context, log và header phản hồi.
func RequestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := r.Header.Get(requestid.Header)
		if !validRequestID(id) {
			id = newID()
		}
		w.Header().Set(requestid.Header, id)
		ctx := requestid.With(r.Context(), id)
		ctx = log.WithAttrs(ctx, "request_id", id)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func newID() string {
	if id, err := uuid.NewV7(); err == nil {
		return id.String()
	}
	return uuid.NewString()
}

// validRequestID chỉ chấp nhận ký tự an toàn để tránh log injection.
func validRequestID(s string) bool {
	if s == "" || len(s) > maxRequestIDLen {
		return false
	}
	for _, c := range s {
		switch {
		case c >= 'a' && c <= 'z', c >= 'A' && c <= 'Z', c >= '0' && c <= '9', c == '-', c == '_', c == '.':
		default:
			return false
		}
	}
	return true
}
