package middleware

import (
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"runtime/debug"

	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/problem"
	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
)

// Recover bắt panic trong handler, log kèm stack và trả 500 problem+json.
// http.ErrAbortHandler được ném lại theo đúng quy ước của net/http.
func Recover(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() { //nolint:contextcheck // dùng r.Context() của chính request đang xử lý
			rec := recover()
			if rec == nil {
				return
			}
			if err, ok := rec.(error); ok && errors.Is(err, http.ErrAbortHandler) {
				panic(rec)
			}
			slog.ErrorContext(r.Context(), "panic recovered",
				"panic", fmt.Sprint(rec), "stack", string(debug.Stack()))
			problem.Write(w, r, apperr.Internal(fmt.Errorf("panic: %v", rec)))
		}()
		next.ServeHTTP(w, r)
	})
}
