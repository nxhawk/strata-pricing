package queryapi

import (
	"net/http"

	httpin "github.com/nxhawk/strata-pricing/internal/adapter/in/http"
	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/problem"
	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
	"github.com/nxhawk/strata-pricing/internal/domain/identity"
)

// MeResponse là thân phản hồi GET /api/v1/query/me (UC-01).
//
// permissions được suy ra từ ma trận RBAC ở backend để frontend ẩn/hiện chức
// năng mà không phải lặp lại logic phân quyền.
type MeResponse struct {
	ID            string   `json:"id"`
	Username      string   `json:"username"`
	Name          string   `json:"name"`
	Email         string   `json:"email,omitempty"`
	Kind          string   `json:"kind"`
	Roles         []string `json:"roles"`
	SupplierScope []string `json:"supplierScope"`
	AllSuppliers  bool     `json:"allSuppliers"`
	Permissions   []string `json:"permissions"`
}

func (a *API) getMe(w http.ResponseWriter, r *http.Request) {
	actor, ok := identity.FromContext(r.Context())
	if !ok {
		problem.Write(w, r, apperr.Unauthenticated("Chưa xác thực", nil))
		return
	}
	httpin.WriteJSON(w, http.StatusOK, toMeResponse(actor))
}

func toMeResponse(a identity.Actor) MeResponse {
	roles := make([]string, len(a.Roles))
	for i, r := range a.Roles {
		roles[i] = r.String()
	}
	perms := a.Permissions()
	permStr := make([]string, len(perms))
	for i, p := range perms {
		permStr[i] = string(p)
	}
	scope := a.SupplierScope
	if scope == nil {
		scope = []string{}
	}
	return MeResponse{
		ID:            a.ID,
		Username:      a.Username,
		Name:          a.Name,
		Email:         a.Email,
		Kind:          string(a.Kind),
		Roles:         roles,
		SupplierScope: scope,
		AllSuppliers:  a.HasAllSuppliers(),
		Permissions:   permStr,
	}
}
