package queryapi_test

import (
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	httpin "github.com/nxhawk/strata-pricing/internal/adapter/in/http"
	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/queryapi"
	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
	"github.com/nxhawk/strata-pricing/internal/domain/identity"
)

type stubVerifier struct{ actor identity.Actor }

func (s stubVerifier) Verify(_ context.Context, raw string) (identity.Actor, error) {
	if raw != "t" {
		return identity.Actor{}, apperr.Unauthenticated("bad", nil)
	}
	return s.actor, nil
}

func getMe(t *testing.T, actor identity.Actor) queryapi.MeResponse {
	t.Helper()
	h := httpin.NewRouter(httpin.Deps{
		Logger:   slog.New(slog.NewJSONHandler(io.Discard, nil)),
		Verifier: stubVerifier{actor},
	}, "/api/v1/query", queryapi.New().Mount)

	req := httptest.NewRequest(http.MethodGet, "/api/v1/query/me", nil)
	req.Header.Set("Authorization", "Bearer t")
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	require.Equal(t, http.StatusOK, rec.Code, rec.Body.String())
	assert.Equal(t, "application/json; charset=utf-8", rec.Header().Get("Content-Type"))

	var me queryapi.MeResponse
	require.NoError(t, json.Unmarshal(rec.Body.Bytes(), &me))
	return me
}

func TestGetMe_ReturnsRolesScopeAndPermissions(t *testing.T) {
	editor := identity.NewActor("u-1", "editor", "Minh Trần", "editor@strata.local", identity.KindUser,
		[]string{"PRICING_EDITOR", "default-roles-strata"}, []string{"ACME", "BMI"})

	me := getMe(t, editor)

	assert.Equal(t, "u-1", me.ID)
	assert.Equal(t, "editor", me.Username)
	assert.Equal(t, "Minh Trần", me.Name)
	assert.Equal(t, "user", me.Kind)
	assert.Equal(t, []string{"PRICING_EDITOR"}, me.Roles)
	assert.Equal(t, []string{"ACME", "BMI"}, me.SupplierScope)
	assert.False(t, me.AllSuppliers)
	assert.Contains(t, me.Permissions, "draft.edit")
	assert.NotContains(t, me.Permissions, "admin.manage")
}

func TestGetMe_EmptyScopeIsArrayNotNull(t *testing.T) {
	sys := identity.NewActor("svc", "service-account-erp", "", "", identity.KindService, []string{"SYSTEM"}, nil)
	me := getMe(t, sys)
	assert.NotNil(t, me.SupplierScope)
	assert.Empty(t, me.SupplierScope)
	assert.Equal(t, "service", me.Kind)
}
