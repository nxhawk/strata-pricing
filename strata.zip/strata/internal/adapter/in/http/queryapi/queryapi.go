// Package queryapi chứa route HTTP của query-svc (SPEC §13.3), gắn dưới
// /api/v1/query. Các route grid, search, as-of... được thêm từ PH-05.
package queryapi

import (
	"github.com/go-chi/chi/v5"
)

// API gom handler của query-svc. Phụ thuộc (use case) được thêm vào đây khi
// có tính năng đọc thật.
type API struct{}

// New tạo API.
func New() *API { return &API{} }

// Mount gắn route vào router đã có middleware xác thực.
func (a *API) Mount(r chi.Router) {
	r.Get("/me", a.getMe)
}
