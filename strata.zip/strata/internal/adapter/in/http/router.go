// Package httpin là inbound adapter HTTP: lắp router, chuỗi middleware chuẩn
// và các tiện ích JSON. Route cụ thể nằm ở queryapi (query-svc) và commandapi
// (command-svc).
package httpin

import (
	"log/slog"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/middleware"
	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/problem"
	"github.com/nxhawk/strata-pricing/internal/app/port"
	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
	"github.com/nxhawk/strata-pricing/internal/platform/metrics"
)

// Mặc định theo ARCH §6.1 và §10.1.
const (
	DefaultTimeout      = 6 * time.Second
	DefaultMaxBodyBytes = 1 << 20 // 1MB JSON
)

// Deps là các phụ thuộc của router.
type Deps struct {
	Logger       *slog.Logger
	Metrics      *metrics.HTTP
	Verifier     port.TokenVerifier
	Timeout      time.Duration // 0 -> DefaultTimeout
	MaxBodyBytes int64         // 0 -> DefaultMaxBodyBytes
}

// NewRouter dựng router với chuỗi middleware chuẩn, gắn các route của service
// dưới apiPrefix (ví dụ "/api/v1/query"). Mọi route dưới apiPrefix đều yêu cầu
// xác thực.
//
// Thứ tự middleware (ngoài -> trong):
//
//	request-id -> tracing -> observe (access log + metric) -> recover
//	-> timeout -> body-limit -> authn -> [route: authz, idempotency...]
//
// So với ARCH §6.1, request-id và tracing được đặt trước recover để log của
// panic vẫn có request_id/trace_id; observe bọc ngoài recover để panic vẫn
// được tính là 500 trong metric. Xem docs/deviations.md.
func NewRouter(d Deps, apiPrefix string, mount func(r chi.Router)) http.Handler {
	if d.Timeout == 0 {
		d.Timeout = DefaultTimeout
	}
	if d.MaxBodyBytes == 0 {
		d.MaxBodyBytes = DefaultMaxBodyBytes
	}

	r := chi.NewRouter()
	r.Use(
		middleware.RequestID,
		middleware.Tracing,
		middleware.Observe(d.Logger, d.Metrics),
		middleware.Recover,
		middleware.Timeout(d.Timeout),
		middleware.BodyLimit(d.MaxBodyBytes),
	)
	r.NotFound(func(w http.ResponseWriter, req *http.Request) {
		problem.Write(w, req, apperr.NotFound("Không tìm thấy tài nguyên"))
	})
	r.MethodNotAllowed(func(w http.ResponseWriter, req *http.Request) {
		problem.Write(w, req, apperr.New(apperr.KindInvalid, apperr.CodeMethodNotAllowed, "Phương thức không được hỗ trợ"))
	})

	r.Route(apiPrefix, func(api chi.Router) {
		api.Use(middleware.Authenticate(d.Verifier))
		mount(api)
	})
	return r
}
