package problem_test

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/problem"
	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
	"github.com/nxhawk/strata-pricing/internal/platform/requestid"
)

func TestFromError_StatusMapping(t *testing.T) {
	tests := []struct {
		name   string
		err    error
		status int
		code   string
	}{
		{"validation", apperr.Validation(apperr.FieldError{Field: "listPrice", Code: "E_PRICE_INVALID"}), 400, apperr.CodeValidation},
		{"unauthenticated", apperr.Unauthenticated("bad token", nil), 401, apperr.CodeUnauthenticated},
		{"out of scope", apperr.Forbidden(apperr.CodeSupplierOutOfScope, "x"), 403, apperr.CodeSupplierOutOfScope},
		{"not found", apperr.NotFound("x"), 404, apperr.CodeNotFound},
		{"conflict", apperr.Conflict(apperr.CodeVersionConflict, "x", nil), 409, apperr.CodeVersionConflict},
		{"reason required -> 422", apperr.Invalid(apperr.CodeReasonRequired, "x"), 422, apperr.CodeReasonRequired},
		{"rate limited -> 429", apperr.New(apperr.KindUnavailable, apperr.CodeRateLimited, "x"), 429, apperr.CodeRateLimited},
		{"wrapped", fmt.Errorf("handler: %w", apperr.NotFound("x")), 404, apperr.CodeNotFound},
		{"deadline", context.DeadlineExceeded, 503, apperr.CodeUnavailable},
		{"body too large", &http.MaxBytesError{Limit: 1}, 413, apperr.CodePayloadTooLarge},
		{"unknown", errors.New("secret db detail"), 500, apperr.CodeInternal},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := problem.FromError(tt.err)
			assert.Equal(t, tt.status, p.Status)
			assert.Equal(t, tt.code, p.Code)
			assert.NotContains(t, p.Detail, "secret")
		})
	}
}

func TestWrite_ProblemJSONWithRequestID(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/v1/query/me", nil)
	req = req.WithContext(requestid.With(req.Context(), "req-123"))
	rec := httptest.NewRecorder()

	problem.Write(rec, req, apperr.Unauthenticated("token expired", nil))

	assert.Equal(t, 401, rec.Code)
	assert.Equal(t, problem.ContentType, rec.Header().Get("Content-Type"))
	assert.Contains(t, rec.Header().Get("WWW-Authenticate"), "Bearer")

	var p problem.Problem
	require.NoError(t, json.Unmarshal(rec.Body.Bytes(), &p))
	assert.Equal(t, "req-123", p.RequestID)
	assert.Equal(t, "/api/v1/query/me", p.Instance)
	assert.Equal(t, "urn:strata:problem:unauthenticated", p.Type)
}
