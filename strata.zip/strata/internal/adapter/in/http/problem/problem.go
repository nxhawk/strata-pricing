// Package problem ghi lỗi theo RFC 9457 (application/problem+json) và là nơi
// DUY NHẤT ánh xạ lỗi ứng dụng (apperr) sang HTTP status (ARCH §5.5, SPEC §13.4).
package problem

import (
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http"
	"strings"

	"github.com/nxhawk/strata-pricing/internal/domain/apperr"
	"github.com/nxhawk/strata-pricing/internal/platform/requestid"
)

// ContentType theo RFC 9457.
const ContentType = "application/problem+json"

// Problem là thân phản hồi lỗi. Trường mở rộng: code, requestId, errors, details.
type Problem struct {
	Type      string              `json:"type"`
	Title     string              `json:"title"`
	Status    int                 `json:"status"`
	Detail    string              `json:"detail,omitempty"`
	Instance  string              `json:"instance,omitempty"`
	Code      string              `json:"code"`
	RequestID string              `json:"requestId,omitempty"`
	Errors    []apperr.FieldError `json:"errors,omitempty"`
	Details   map[string]any      `json:"details,omitempty"`
}

// statusByCode ghi đè status cho các mã không theo status mặc định của Kind.
var statusByCode = map[string]int{
	apperr.CodeReasonRequired:    http.StatusUnprocessableEntity,
	apperr.CodeFourEyesViolation: http.StatusUnprocessableEntity,
	apperr.CodeRetroactive:       http.StatusUnprocessableEntity,
	apperr.CodeIdempotencyReused: http.StatusUnprocessableEntity,
	apperr.CodeFileTooLarge:      http.StatusRequestEntityTooLarge,
	apperr.CodePayloadTooLarge:   http.StatusRequestEntityTooLarge,
	apperr.CodeUnsupportedFormat: http.StatusUnsupportedMediaType,
	apperr.CodeRateLimited:       http.StatusTooManyRequests,
	apperr.CodeMethodNotAllowed:  http.StatusMethodNotAllowed,
}

var statusByKind = map[apperr.Kind]int{
	apperr.KindInvalid:         http.StatusBadRequest,
	apperr.KindUnauthenticated: http.StatusUnauthorized,
	apperr.KindForbidden:       http.StatusForbidden,
	apperr.KindNotFound:        http.StatusNotFound,
	apperr.KindConflict:        http.StatusConflict,
	apperr.KindUnavailable:     http.StatusServiceUnavailable,
	apperr.KindInternal:        http.StatusInternalServerError,
}

// FromError chuyển lỗi bất kỳ thành Problem. Lỗi không có kiểu được coi là
// INTERNAL và không lộ chi tiết ra client.
func FromError(err error) Problem {
	var mbe *http.MaxBytesError
	switch {
	case errors.As(err, &mbe):
		err = apperr.New(apperr.KindInvalid, apperr.CodePayloadTooLarge, "Dữ liệu gửi lên quá lớn")
	case errors.Is(err, context.DeadlineExceeded):
		err = apperr.Unavailable("Hết thời gian xử lý", err)
	case errors.Is(err, context.Canceled):
		err = apperr.Unavailable("Request đã bị huỷ", err)
	}

	e, ok := apperr.As(err)
	if !ok {
		e = apperr.Internal(err)
	}
	status, ok := statusByCode[e.Code]
	if !ok {
		status, ok = statusByKind[e.Kind]
		if !ok {
			status = http.StatusInternalServerError
		}
	}
	p := Problem{
		Type:    "urn:strata:problem:" + strings.ToLower(e.Code),
		Title:   http.StatusText(status),
		Status:  status,
		Detail:  e.Msg,
		Code:    e.Code,
		Errors:  e.Fields,
		Details: e.Details,
	}
	if status >= 500 && e.Kind == apperr.KindInternal {
		p.Detail = "Hệ thống đang gián đoạn. Dữ liệu của bạn không bị ảnh hưởng."
	}
	return p
}

// Write ghi lỗi ra response. Lỗi 5xx được log ERROR kèm nguyên nhân gốc;
// lỗi nghiệp vụ dự kiến (4xx) chỉ log ở access log (ARCH §12.4).
func Write(w http.ResponseWriter, r *http.Request, err error) {
	p := FromError(err)
	p.Instance = r.URL.Path
	p.RequestID = requestid.From(r.Context())

	if p.Status >= 500 && !errors.Is(err, context.Canceled) {
		slog.ErrorContext(r.Context(), "request failed",
			"err", err, "err_kind", apperr.KindOf(err).String(), "code", p.Code)
	}
	WriteProblem(w, p)
}

// WriteProblem ghi một Problem đã dựng sẵn.
func WriteProblem(w http.ResponseWriter, p Problem) {
	w.Header().Set("Content-Type", ContentType)
	w.Header().Set("Cache-Control", "no-store")
	if p.Status == http.StatusUnauthorized {
		w.Header().Set("WWW-Authenticate", `Bearer error="invalid_token"`)
	}
	w.WriteHeader(p.Status)
	_ = json.NewEncoder(w).Encode(p)
}
