// Package commandapi chứa route HTTP của command-svc (SPEC §13.2), gắn dưới
// /api/v1/commands. PH-01 mới có khung (xác thực, problem+json, metric);
// command đầu tiên (HotfixPrice) được thêm ở PH-03, API quản trị ở PH-02.
package commandapi

import "github.com/go-chi/chi/v5"

// API gom handler của command-svc.
type API struct{}

// New tạo API.
func New() *API { return &API{} }

// Mount gắn route vào router đã có middleware xác thực.
func (a *API) Mount(_ chi.Router) {}
