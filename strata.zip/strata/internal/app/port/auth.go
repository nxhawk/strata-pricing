// Package port khai báo các interface mà application layer cần từ hạ tầng
// (ARCH §5.3). Adapter outbound hiện thực, composition root (cmd/*) nối dây.
package port

import (
	"context"

	"github.com/nxhawk/strata-pricing/internal/domain/identity"
)

// TokenVerifier kiểm tra access token (JWT) và dựng Actor.
//
// Hiện thực phải trả *apperr.Error kind Unauthenticated khi token không hợp lệ,
// hết hạn hoặc sai audience; lỗi hạ tầng (không tải được JWKS) trả kind Unavailable.
type TokenVerifier interface {
	Verify(ctx context.Context, rawToken string) (identity.Actor, error)
}
