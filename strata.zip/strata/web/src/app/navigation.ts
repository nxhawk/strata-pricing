import {
  ChartColumn,
  ClipboardCheck,
  History,
  Layers,
  Settings,
  Tags,
  type LucideIcon,
} from 'lucide-react';

import type { Permission } from '@/auth/permissions';
import { env } from '@/config/env';

/**
 * Quyền cần để vào từng route (SPEC §15.1, §16.1; UX §4.2). Dùng chung cho
 * route guard (router.tsx) và sidebar để hai nơi không bao giờ lệch nhau.
 * Danh sách nghĩa là "có ít nhất một quyền".
 */
export const ROUTE_ACCESS = {
  prices: ['price.view'],
  fileVersions: ['version.view'],
  upload: ['file.upload'],
  approvals: ['version.approve', 'version.submit'],
  asOf: ['price.history'],
  admin: ['admin.manage'],
  dashboard: ['dashboard.view'],
} as const satisfies Record<string, readonly Permission[]>;

export type NavKey = keyof typeof ROUTE_ACCESS;

/** Mục có trên sidebar (upload là trang con, không có mục riêng). */
export type SidebarKey = Exclude<NavKey, 'upload'>;

export interface NavItem {
  key: SidebarKey;
  labelKey: `nav.${SidebarKey}`;
  icon: LucideIcon;
  /** Route nội bộ; hoặc href cho liên kết ngoài (mở tab mới). */
  to?: string;
  href?: string;
}

/** Thứ tự mục sidebar theo UX §4.2. */
export const NAV_ITEMS: readonly NavItem[] = [
  { key: 'prices', labelKey: 'nav.prices', icon: Tags, to: '/prices' },
  { key: 'fileVersions', labelKey: 'nav.fileVersions', icon: Layers, to: '/file-versions' },
  { key: 'approvals', labelKey: 'nav.approvals', icon: ClipboardCheck, to: '/approvals' },
  { key: 'asOf', labelKey: 'nav.asOf', icon: History, to: '/as-of' },
  { key: 'dashboard', labelKey: 'nav.dashboard', icon: ChartColumn, href: env.grafanaUrl },
  { key: 'admin', labelKey: 'nav.admin', icon: Settings, to: '/admin' },
];
