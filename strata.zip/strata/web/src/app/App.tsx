import { QueryClientProvider } from '@tanstack/react-query';
import type { User } from 'oidc-client-ts';
import { useState } from 'react';
import { AuthProvider } from 'react-oidc-context';
import { RouterProvider } from 'react-router-dom';

import { AuthGate } from '@/auth/AuthGate';
import { userManager, type SigninState } from '@/auth/userManager';

import { createQueryClient } from './queryClient';
import { router } from './router';

/** Sau khi Keycloak chuyển về: bỏ ?code&state khỏi URL và quay lại trang ban đầu. */
function onSigninCallback(user: User | void) {
  const returnTo = (user?.state as SigninState | undefined)?.returnTo ?? '/prices';
  void router.navigate(returnTo, { replace: true });
}

export function App() {
  const [queryClient] = useState(createQueryClient);
  return (
    <AuthProvider userManager={userManager} onSigninCallback={onSigninCallback}>
      <QueryClientProvider client={queryClient}>
        <AuthGate>
          <RouterProvider router={router} future={{ v7_startTransition: true }} />
        </AuthGate>
      </QueryClientProvider>
    </AuthProvider>
  );
}
