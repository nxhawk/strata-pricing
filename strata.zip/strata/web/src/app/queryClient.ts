import { QueryClient } from '@tanstack/react-query';

import { isApiError } from '@/api/problem';

/** Chỉ thử lại lỗi tạm thời (mạng, 5xx, 429), tối đa 2 lần. Lỗi 4xx không thử lại. */
export function shouldRetry(failureCount: number, error: unknown): boolean {
  return failureCount < 2 && isApiError(error) && error.retryable;
}

export function createQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: { retry: shouldRetry, staleTime: 30_000, refetchOnWindowFocus: false },
      mutations: { retry: false },
    },
  });
}
