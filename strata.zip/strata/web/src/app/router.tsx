import type { ReactNode } from 'react';
import { createBrowserRouter, Navigate, type RouteObject } from 'react-router-dom';

import type { Permission } from '@/auth/permissions';
import { RequirePermission } from '@/auth/RequirePermission';
import { CALLBACK_PATH } from '@/auth/userManager';
import { AppShell } from '@/layout/AppShell';
import { AdminLayout } from '@/pages/admin/AdminLayout';
import { AdminSection } from '@/pages/admin/AdminSection';
import {
  ApprovalsPage,
  AsOfPage,
  FileVersionDetailPage,
  FileVersionsPage,
  NotFoundPage,
  PricesPage,
  UploadWizardPage,
} from '@/pages/pages';

import { ROUTE_ACCESS } from './navigation';
import type { RouteHandle } from './routeHandle';

const guard = (anyOf: readonly Permission[], element: ReactNode) => (
  <RequirePermission anyOf={anyOf}>{element}</RequirePermission>
);

/** Toàn bộ route theo SPEC §15.1. Quyền lấy từ ROUTE_ACCESS (dùng chung với sidebar). */
export const routes: RouteObject[] = [
  {
    path: '/',
    element: <AppShell />,
    children: [
      { index: true, element: <Navigate to="/prices" replace /> },
      // Keycloak chuyển về đây; AuthProvider xử lý code rồi điều hướng tới returnTo.
      { path: CALLBACK_PATH.slice(1), element: <Navigate to="/prices" replace /> },
      {
        path: 'prices',
        handle: { crumb: 'nav.prices' } satisfies RouteHandle,
        element: guard(ROUTE_ACCESS.prices, <PricesPage />),
      },
      {
        path: 'file-versions',
        handle: { crumb: 'nav.fileVersions' } satisfies RouteHandle,
        children: [
          { index: true, element: guard(ROUTE_ACCESS.fileVersions, <FileVersionsPage />) },
          {
            path: 'new',
            handle: { crumb: 'pages.upload.title' } satisfies RouteHandle,
            element: guard(ROUTE_ACCESS.upload, <UploadWizardPage />),
          },
          {
            path: ':id',
            handle: { crumb: 'pages.fileVersionDetail.title' } satisfies RouteHandle,
            element: guard(ROUTE_ACCESS.fileVersions, <FileVersionDetailPage />),
          },
        ],
      },
      {
        path: 'approvals',
        handle: { crumb: 'nav.approvals' } satisfies RouteHandle,
        element: guard(ROUTE_ACCESS.approvals, <ApprovalsPage />),
      },
      {
        path: 'as-of',
        handle: { crumb: 'nav.asOf' } satisfies RouteHandle,
        element: guard(ROUTE_ACCESS.asOf, <AsOfPage />),
      },
      {
        path: 'admin',
        handle: { crumb: 'nav.admin' } satisfies RouteHandle,
        element: guard(ROUTE_ACCESS.admin, <AdminLayout />),
        children: [
          { index: true, element: <Navigate to="suppliers" replace /> },
          {
            path: 'suppliers',
            handle: { crumb: 'pages.admin.suppliers' } satisfies RouteHandle,
            element: <AdminSection />,
          },
          {
            path: 'templates',
            handle: { crumb: 'pages.admin.templates' } satisfies RouteHandle,
            element: <AdminSection />,
          },
          {
            path: 'users',
            handle: { crumb: 'pages.admin.users' } satisfies RouteHandle,
            element: <AdminSection />,
          },
          {
            path: 'settings',
            handle: { crumb: 'pages.admin.settings' } satisfies RouteHandle,
            element: <AdminSection />,
          },
        ],
      },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
];

/** Bật sớm hành vi của React Router v7 để nâng cấp sau này không đổi hành vi. */
export const ROUTER_FUTURE = {
  v7_fetcherPersist: true,
  v7_normalizeFormMethod: true,
  v7_partialHydration: true,
  v7_relativeSplatPath: true,
  v7_skipActionErrorRevalidation: true,
} as const;

export const router = createBrowserRouter(routes, { future: ROUTER_FUTURE });
