import type { ParseKeys } from 'i18next';

/** Metadata gắn vào route (createBrowserRouter `handle`). */
export interface RouteHandle {
  /** Khoá i18n hiển thị trên breadcrumb. */
  crumb?: ParseKeys;
}
