import { useEffect, useRef } from 'react';

export interface Hotkey {
  key: string; // so khớp KeyboardEvent.key, không phân biệt hoa thường
  ctrlOrMeta?: boolean; // Ctrl trên Windows/Linux, Cmd trên macOS
  shift?: boolean;
}

/** Đăng ký phím tắt toàn cục (UX P5 "Bàn phím trước, chuột sau"). */
export function useHotkey(hotkey: Hotkey, handler: (e: KeyboardEvent) => void): void {
  const ref = useRef(handler);
  ref.current = handler;
  const { key, ctrlOrMeta = false, shift = false } = hotkey;

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() !== key.toLowerCase()) return;
      if (ctrlOrMeta !== (e.ctrlKey || e.metaKey)) return;
      if (shift !== e.shiftKey) return;
      e.preventDefault();
      ref.current(e);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [key, ctrlOrMeta, shift]);
}
