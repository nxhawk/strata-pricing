import { useTranslation } from 'react-i18next';
import { NavLink, Outlet } from 'react-router-dom';

import { PageHeader } from '@/components/PageHeader';

import './AdminLayout.css';

const TABS = [
  { to: 'suppliers', labelKey: 'pages.admin.suppliers' },
  { to: 'templates', labelKey: 'pages.admin.templates' },
  { to: 'users', labelKey: 'pages.admin.users' },
  { to: 'settings', labelKey: 'pages.admin.settings' },
] as const;

/** /admin/* (SPEC §15.1). Nội dung các tab làm ở PH-02. */
export function AdminLayout() {
  const { t } = useTranslation();
  return (
    <>
      <PageHeader title={t('pages.admin.title')} description={t('pages.admin.description')} />
      <nav className="admin-tabs" aria-label={t('pages.admin.tabs')}>
        {TABS.map((tab) => (
          <NavLink key={tab.to} to={tab.to} className="admin-tabs__tab">
            {t(tab.labelKey)}
          </NavLink>
        ))}
      </nav>
      <Outlet />
    </>
  );
}
