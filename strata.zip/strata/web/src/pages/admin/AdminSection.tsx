import { Construction } from 'lucide-react';
import { useTranslation } from 'react-i18next';

import { EmptyState } from '@/components/states/EmptyState';

/** Nội dung tạm của một tab quản trị (PH-02). */
export function AdminSection() {
  const { t } = useTranslation();
  return (
    <section className="card">
      <EmptyState
        icon={Construction}
        title={t('placeholder.title')}
        body={t('placeholder.body', { phase: 'PH-02' })}
      />
    </section>
  );
}
