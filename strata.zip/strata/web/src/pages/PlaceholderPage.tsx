import { Construction } from 'lucide-react';
import { useTranslation } from 'react-i18next';

import { EmptyState } from '@/components/states/EmptyState';
import { PageHeader } from '@/components/PageHeader';

interface Props {
  title: string;
  description: string;
  /** Phase trong PLAN-001 sẽ xây màn hình này, ví dụ "PH-05". */
  phase: string;
}

/** Khung trang tạm của PH-01: đủ tiêu đề và trạng thái rỗng, nội dung thật đến ở phase sau. */
export function PlaceholderPage({ title, description, phase }: Props) {
  const { t } = useTranslation();
  return (
    <>
      <PageHeader title={title} description={description} />
      <section className="card">
        <EmptyState
          icon={Construction}
          title={t('placeholder.title')}
          body={t('placeholder.body', { phase })}
        />
      </section>
    </>
  );
}
