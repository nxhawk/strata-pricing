/**
 * Các trang theo SPEC §15.1. PH-01 chỉ có khung; mỗi trang ghi rõ phase sẽ làm
 * nội dung thật (PLAN-001 §3).
 */
import { useTranslation } from 'react-i18next';
import { Link, useParams } from 'react-router-dom';

import { EmptyState } from '@/components/states/EmptyState';

import { PlaceholderPage } from './PlaceholderPage';

export function PricesPage() {
  const { t } = useTranslation();
  return (
    <PlaceholderPage
      title={t('pages.prices.title')}
      description={t('pages.prices.description')}
      phase="PH-05"
    />
  );
}

export function FileVersionsPage() {
  const { t } = useTranslation();
  return (
    <PlaceholderPage
      title={t('pages.fileVersions.title')}
      description={t('pages.fileVersions.description')}
      phase="PH-06"
    />
  );
}

export function UploadWizardPage() {
  const { t } = useTranslation();
  return (
    <PlaceholderPage
      title={t('pages.upload.title')}
      description={t('pages.upload.description')}
      phase="PH-06"
    />
  );
}

export function FileVersionDetailPage() {
  const { t } = useTranslation();
  const { id = '' } = useParams();
  return (
    <PlaceholderPage
      title={t('pages.fileVersionDetail.title')}
      description={t('pages.fileVersionDetail.description', { id })}
      phase="PH-08"
    />
  );
}

export function ApprovalsPage() {
  const { t } = useTranslation();
  return (
    <PlaceholderPage
      title={t('pages.approvals.title')}
      description={t('pages.approvals.description')}
      phase="PH-11"
    />
  );
}

export function AsOfPage() {
  const { t } = useTranslation();
  return (
    <PlaceholderPage
      title={t('pages.asOf.title')}
      description={t('pages.asOf.description')}
      phase="PH-13"
    />
  );
}

export function NotFoundPage() {
  const { t } = useTranslation();
  return (
    <EmptyState
      title={t('pages.notFound.title')}
      body={t('pages.notFound.description')}
      action={
        <Link className="btn btn--primary" to="/prices">
          {t('pages.notFound.action')}
        </Link>
      }
    />
  );
}
