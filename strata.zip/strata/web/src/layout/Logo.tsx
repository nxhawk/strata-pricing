/** Logo Strata: ba lớp xếp chồng, lớp dưới đậm nhất là giá đang hiệu lực (UX §6.1). */
export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <path d="M16 5 28 11 16 17 4 11Z" fill="#C7CEF8" opacity=".5" />
      <path
        d="M4 16 16 22 28 16"
        fill="none"
        stroke="#8E9BF0"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
      <path
        d="M4 21 16 27 28 21"
        fill="none"
        stroke="#5B6CF0"
        strokeWidth="2.8"
        strokeLinejoin="round"
      />
    </svg>
  );
}
