import { ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link, useMatches } from 'react-router-dom';

import type { RouteHandle } from '@/app/routeHandle';

/** Breadcrumb dựng từ `handle.crumb` của các route đang khớp (UX §4.3). */
export function Breadcrumbs() {
  const { t } = useTranslation();
  const crumbs = useMatches()
    .filter((m) => (m.handle as RouteHandle | undefined)?.crumb)
    .map((m) => ({ path: m.pathname, key: (m.handle as RouteHandle).crumb! }));

  if (crumbs.length === 0) return null;
  return (
    <nav aria-label={t('topbar.breadcrumb')} className="breadcrumbs">
      <ol>
        {crumbs.map((c, i) => {
          const last = i === crumbs.length - 1;
          return (
            <li key={c.path}>
              {i > 0 && <ChevronRight size={14} aria-hidden="true" />}
              {last ? (
                <span aria-current="page">{t(c.key)}</span>
              ) : (
                <Link to={c.path}>{t(c.key)}</Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
