import { ExternalLink, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { NavLink } from 'react-router-dom';

import { NAV_ITEMS, ROUTE_ACCESS } from '@/app/navigation';
import { useCurrentUser } from '@/auth/useCurrentUser';

import { Logo } from './Logo';

interface Props {
  collapsed: boolean;
  onToggle: () => void;
}

/** Sidebar (UX §4.2 - §4.3): chỉ hiện mục người dùng có quyền; thu gọn bằng Ctrl B. */
export function Sidebar({ collapsed, onToggle }: Props) {
  const { t } = useTranslation();
  const { canAny } = useCurrentUser();
  const items = NAV_ITEMS.filter((item) => canAny(ROUTE_ACCESS[item.key]));

  return (
    <aside className="sidebar" data-collapsed={collapsed}>
      <div className="sidebar__brand">
        <Logo />
        {!collapsed && <span className="sidebar__name">{t('app.name')}</span>}
      </div>

      <nav className="sidebar__nav" aria-label={t('nav.label')}>
        <ul>
          {items.map((item) => {
            const Icon = item.icon;
            const label = t(item.labelKey);
            const content = (
              <>
                <Icon size={18} aria-hidden="true" />
                {!collapsed && <span className="sidebar__label">{label}</span>}
                {!collapsed && item.href && (
                  <ExternalLink size={14} aria-hidden="true" className="sidebar__ext" />
                )}
              </>
            );
            return (
              <li key={item.key}>
                {item.href ? (
                  <a
                    className="sidebar__item"
                    href={item.href}
                    target="_blank"
                    rel="noreferrer"
                    title={collapsed ? label : undefined}
                    aria-label={`${label} (${t('nav.opensNewTab')})`}
                  >
                    {content}
                  </a>
                ) : (
                  <NavLink
                    className="sidebar__item"
                    to={item.to ?? '/'}
                    title={collapsed ? label : undefined}
                    aria-label={collapsed ? label : undefined}
                  >
                    {content}
                  </NavLink>
                )}
              </li>
            );
          })}
        </ul>
      </nav>

      <button
        type="button"
        className="sidebar__toggle"
        onClick={onToggle}
        aria-label={collapsed ? t('nav.expand') : t('nav.collapse')}
        title={collapsed ? t('nav.expand') : t('nav.collapse')}
        aria-expanded={!collapsed}
      >
        {collapsed ? (
          <PanelLeftOpen size={18} aria-hidden="true" />
        ) : (
          <PanelLeftClose size={18} aria-hidden="true" />
        )}
      </button>
    </aside>
  );
}
