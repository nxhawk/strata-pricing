import { Search } from 'lucide-react';
import { useRef, useState, type FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

import { useHotkey } from '@/hooks/useHotkey';

/**
 * Ô tìm kiếm toàn cục (UX §4.3), Ctrl K để focus. PH-01: Enter chuyển sang
 * /prices?q=... ; gợi ý SKU/sản phẩm/version/NCC theo thời gian thực đến ở PH-05.
 */
export function GlobalSearch() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [q, setQ] = useState('');

  useHotkey({ key: 'k', ctrlOrMeta: true }, () => inputRef.current?.focus());

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    if (term) navigate(`/prices?q=${encodeURIComponent(term)}`);
  };

  return (
    <form role="search" className="global-search" onSubmit={submit}>
      <Search size={16} aria-hidden="true" className="global-search__icon" />
      <input
        ref={inputRef}
        type="search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        aria-label={t('topbar.searchLabel')}
        placeholder={t('topbar.searchPlaceholder')}
        aria-keyshortcuts="Control+K"
      />
      <kbd aria-hidden="true">Ctrl K</kbd>
    </form>
  );
}
