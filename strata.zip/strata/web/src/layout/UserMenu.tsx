import { useQueryClient } from '@tanstack/react-query';
import { LogOut } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useAuth } from 'react-oidc-context';

import type { Me } from '@/api/me';
import { Popover } from '@/components/Popover';
import { SUPPORTED_LANGUAGES } from '@/i18n';
import { useUiStore, type Density } from '@/stores/uiStore';

const DENSITIES: readonly Density[] = ['compact', 'default', 'comfortable'];

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const pick = parts.length > 1 ? [parts[0], parts[parts.length - 1]] : parts;
  return (
    pick
      .map((p) => p?.[0] ?? '')
      .join('')
      .toUpperCase() || '?'
  );
}

/** Menu avatar (UX §4.3): hồ sơ, vai trò, phạm vi NCC, ngôn ngữ, mật độ grid, đăng xuất. */
export function UserMenu({ me }: { me: Me }) {
  const { t } = useTranslation();
  const auth = useAuth();
  const queryClient = useQueryClient();
  const { language, setLanguage, density, setDensity } = useUiStore();
  const displayName = me.name || me.username;

  const logout = () => {
    queryClient.clear();
    void auth.signoutRedirect();
  };

  return (
    <Popover
      label={t('topbar.userMenu')}
      triggerClassName="avatar-btn"
      trigger={<span className="avatar">{initials(displayName)}</span>}
    >
      <div className="user-menu">
        <div className="user-menu__who">
          <strong>{displayName}</strong>
          <span className="mono">{me.username}</span>
        </div>
        <ul className="user-menu__roles" aria-label={t('topbar.roles')}>
          {me.roles.map((r) => (
            <li key={r} className="chip">
              {t(`roles.${r}`)}
            </li>
          ))}
        </ul>
        <p className="user-menu__scope">
          {t('topbar.supplierScope')}:{' '}
          {me.allSuppliers ? t('topbar.allSuppliers') : me.supplierScope.join(', ') || '—'}
        </p>

        <fieldset className="user-menu__group">
          <legend>{t('topbar.language')}</legend>
          {SUPPORTED_LANGUAGES.map((l) => (
            <label key={l}>
              <input
                type="radio"
                name="language"
                checked={language === l}
                onChange={() => setLanguage(l)}
              />
              {t(`language.${l}`)}
            </label>
          ))}
        </fieldset>

        <fieldset className="user-menu__group">
          <legend>{t('topbar.density')}</legend>
          {DENSITIES.map((d) => (
            <label key={d}>
              <input
                type="radio"
                name="density"
                checked={density === d}
                onChange={() => setDensity(d)}
              />
              {t(`density.${d}`)}
            </label>
          ))}
        </fieldset>

        <button type="button" className="btn user-menu__logout" onClick={logout}>
          <LogOut size={16} aria-hidden="true" />
          {t('topbar.logout')}
        </button>
      </div>
    </Popover>
  );
}
