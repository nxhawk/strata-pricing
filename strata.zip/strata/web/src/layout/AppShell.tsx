import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Outlet } from 'react-router-dom';

import { useCurrentUser } from '@/auth/useCurrentUser';
import { ErrorState } from '@/components/states/ErrorState';
import { FullPageMessage } from '@/components/states/FullPageMessage';
import { useHotkey } from '@/hooks/useHotkey';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { setLanguage } from '@/i18n';
import { useUiStore } from '@/stores/uiStore';

import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';

import './AppShell.css';

/** Màn hình < 1280px: sidebar tự thu gọn (UX §4.3, §15). */
export const NARROW_QUERY = '(max-width: 1279px)';

/** Khung ứng dụng: skip link, sidebar, top bar, vùng nội dung (UX §4.2 - §4.3, §7.6 AppShell). */
export function AppShell() {
  const { t } = useTranslation();
  const { me, error, refetch, isPending } = useCurrentUser();
  const narrow = useMediaQuery(NARROW_QUERY);
  const { sidebarCollapsedPref, setSidebarCollapsedPref, language, density } = useUiStore();
  const collapsed = sidebarCollapsedPref ?? narrow;
  const toggle = () => setSidebarCollapsedPref(!collapsed);

  useHotkey({ key: 'b', ctrlOrMeta: true }, toggle);
  useEffect(() => setLanguage(language), [language]);

  if (isPending) return <FullPageMessage message={t('states.loading')} busy />;
  if (error || !me) {
    return (
      <div className="full-page">
        <ErrorState error={error} onRetry={() => void refetch()} />
      </div>
    );
  }

  return (
    <div
      className="app-shell"
      data-sidebar={collapsed ? 'collapsed' : 'expanded'}
      data-density={density}
    >
      <a className="skip-link" href="#main">
        {t('skipLink')}
      </a>
      <Sidebar collapsed={collapsed} onToggle={toggle} />
      <div className="app-shell__body">
        <TopBar me={me} />
        <main id="main" className="app-shell__main" tabIndex={-1}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
