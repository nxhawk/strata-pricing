import { Bell } from 'lucide-react';
import { useTranslation } from 'react-i18next';

import type { Me } from '@/api/me';
import { Popover } from '@/components/Popover';

import { Breadcrumbs } from './Breadcrumbs';
import { GlobalSearch } from './GlobalSearch';
import { RealtimeIndicator } from './RealtimeIndicator';
import { UserMenu } from './UserMenu';

/** Top bar cố định trên mọi trang (UX §4.3). */
export function TopBar({ me }: { me: Me }) {
  const { t } = useTranslation();
  return (
    <header className="topbar">
      <Breadcrumbs />
      <div className="topbar__right">
        <GlobalSearch />
        <RealtimeIndicator state="disabled" />
        <Popover label={t('topbar.notifications')} trigger={<Bell size={18} aria-hidden="true" />}>
          <p className="topbar__empty">{t('topbar.noNotifications')}</p>
        </Popover>
        <UserMenu me={me} />
      </div>
    </header>
  );
}
