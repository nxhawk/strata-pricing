import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { makeMe, renderApp } from '@/test/renderApp';

vi.mock('react-oidc-context', () => ({
  useAuth: () => ({ signoutRedirect: vi.fn() }),
}));

function sidebarLabels() {
  const nav = screen.getByRole('navigation', { name: 'Điều hướng chính' });
  return within(nav)
    .getAllByRole('link')
    .map((a) => a.textContent?.trim());
}

describe('AppShell - sidebar theo vai trò (UX §4.2)', () => {
  it.each([
    ['VIEWER', ['Giá hiện hành', 'Tra cứu as-of']],
    ['PRICING_EDITOR', ['Giá hiện hành', 'File version', 'Chờ duyệt', 'Tra cứu as-of']],
    [
      'PRICING_MANAGER',
      ['Giá hiện hành', 'File version', 'Chờ duyệt', 'Tra cứu as-of', 'Dashboard'],
    ],
    ['AUDITOR', ['Giá hiện hành', 'File version', 'Tra cứu as-of', 'Dashboard']],
    ['ADMIN', ['Giá hiện hành', 'File version', 'Tra cứu as-of', 'Dashboard', 'Quản trị']],
  ] as const)('%s thấy đúng các mục', async (role, expected) => {
    renderApp(makeMe(role));
    await screen.findByRole('heading', { level: 1, name: 'Giá hiện hành' });
    expect(sidebarLabels()).toEqual(expected);
  });

  it('Dashboard mở Grafana ở tab mới', async () => {
    renderApp(makeMe('PRICING_MANAGER'));
    const link = await screen.findByRole('link', { name: /Dashboard/ });
    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('href', 'http://localhost:3000');
  });
});

describe('AppShell - phân quyền route', () => {
  it('người không phải ADMIN vào /admin thấy trạng thái không có quyền', async () => {
    renderApp(makeMe('PRICING_EDITOR'), '/admin');
    expect(await screen.findByText('Bạn không có quyền xem trang này')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { level: 1, name: 'Quản trị' })).not.toBeInTheDocument();
  });

  it('ADMIN vào /admin được chuyển tới tab Nhà cung cấp', async () => {
    const { router } = renderApp(makeMe('ADMIN'), '/admin');
    expect(await screen.findByRole('heading', { level: 1, name: 'Quản trị' })).toBeInTheDocument();
    expect(router.state.location.pathname).toBe('/admin/suppliers');
  });

  it('route lạ hiện trang không tìm thấy', async () => {
    renderApp(makeMe('VIEWER'), '/khong-ton-tai');
    expect(await screen.findByText('Không tìm thấy trang')).toBeInTheDocument();
  });

  it('/ chuyển về /prices', async () => {
    const { router } = renderApp(makeMe('VIEWER'), '/');
    await screen.findByRole('heading', { level: 1, name: 'Giá hiện hành' });
    expect(router.state.location.pathname).toBe('/prices');
  });
});

describe('AppShell - bàn phím & khung', () => {
  it('Ctrl+B thu gọn / mở rộng sidebar', async () => {
    const user = userEvent.setup();
    const { container } = renderApp(makeMe('VIEWER'));
    await screen.findByRole('heading', { level: 1 });
    const shell = container.querySelector('.app-shell');
    expect(shell).toHaveAttribute('data-sidebar', 'expanded');

    await user.keyboard('{Control>}b{/Control}');
    expect(shell).toHaveAttribute('data-sidebar', 'collapsed');
    // Thu gọn vẫn có tên truy cập cho từng mục.
    expect(screen.getByRole('link', { name: 'Giá hiện hành' })).toBeInTheDocument();

    await user.keyboard('{Control>}b{/Control}');
    expect(shell).toHaveAttribute('data-sidebar', 'expanded');
  });

  it('Ctrl+K focus ô tìm kiếm toàn cục', async () => {
    const user = userEvent.setup();
    renderApp(makeMe('VIEWER'));
    await screen.findByRole('heading', { level: 1 });
    await user.keyboard('{Control>}k{/Control}');
    expect(screen.getByRole('searchbox', { name: 'Tìm kiếm toàn cục' })).toHaveFocus();
  });

  it('link "Bỏ qua tới nội dung" là phần tử focus đầu tiên', async () => {
    const user = userEvent.setup();
    renderApp(makeMe('VIEWER'));
    await screen.findByRole('heading', { level: 1 });
    await user.tab();
    expect(screen.getByRole('link', { name: 'Bỏ qua tới nội dung' })).toHaveFocus();
  });

  it('breadcrumb hiển thị trang hiện tại', async () => {
    renderApp(makeMe('PRICING_EDITOR'), '/file-versions/new');
    const crumbs = await screen.findByRole('navigation', { name: 'Vị trí hiện tại' });
    expect(within(crumbs).getByRole('link', { name: 'File version' })).toBeInTheDocument();
    expect(within(crumbs).getByText('Upload file giá')).toHaveAttribute('aria-current', 'page');
  });

  it('menu tài khoản hiện vai trò, phạm vi NCC và đổi được ngôn ngữ', async () => {
    const user = userEvent.setup();
    renderApp(makeMe('PRICING_EDITOR'));
    await user.click(await screen.findByRole('button', { name: 'Tài khoản' }));
    const dialog = screen.getByRole('dialog', { name: 'Tài khoản' });
    expect(within(dialog).getByText('Pricing editor')).toBeInTheDocument();
    expect(within(dialog).getByText(/ACME, BMI/)).toBeInTheDocument();

    await user.click(within(dialog).getByRole('radio', { name: 'English' }));
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Current prices' }),
    ).toBeInTheDocument();
    expect(document.documentElement.lang).toBe('en');
  });
});
