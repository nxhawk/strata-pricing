import { useTranslation } from 'react-i18next';

export type RealtimeState = 'online' | 'reconnecting' | 'offline' | 'disabled';

/**
 * Chỉ báo Realtime trên top bar (UX §11.1). PH-01 chưa có WebSocket nên luôn
 * ở trạng thái "disabled"; PH-10 truyền trạng thái thật của kết nối.
 */
export function RealtimeIndicator({ state }: { state: RealtimeState }) {
  const { t } = useTranslation();
  const label = t(`realtime.${state}`);
  return (
    <span
      className={`realtime realtime--${state}`}
      role="status"
      title={state === 'disabled' ? t('realtime.disabledHint') : label}
    >
      <span className="realtime__dot" aria-hidden="true" />
      {label}
    </span>
  );
}
