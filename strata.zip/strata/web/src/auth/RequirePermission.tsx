import type { ReactNode } from 'react';

import { ErrorState } from '@/components/states/ErrorState';
import { ForbiddenState } from '@/components/states/ForbiddenState';
import { LoadingState } from '@/components/states/LoadingState';

import type { Permission } from './permissions';
import { useCurrentUser } from './useCurrentUser';

interface Props {
  anyOf: readonly Permission[];
  children: ReactNode;
}

/** Route guard: hiện trạng thái "không có quyền" thay vì nội dung (UX §17.4). */
export function RequirePermission({ anyOf, children }: Props) {
  const { isPending, error, refetch, canAny } = useCurrentUser();
  if (isPending) return <LoadingState />;
  if (error) return <ErrorState error={error} onRetry={() => void refetch()} />;
  if (!canAny(anyOf)) return <ForbiddenState />;
  return <>{children}</>;
}
