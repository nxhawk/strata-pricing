/**
 * Quyền và vai trò - phản chiếu internal/domain/identity ở backend.
 * Frontend KHÔNG tự suy quyền từ vai trò: luôn dùng danh sách permissions mà
 * GET /api/v1/query/me trả về (backend là nguồn sự thật của ma trận RBAC).
 */
export const PERMISSIONS = [
  'price.view',
  'price.history',
  'file.upload',
  'draft.edit',
  'version.view',
  'version.submit',
  'version.approve',
  'version.discard',
  'version.rollback',
  'price.hotfix',
  'audit.view',
  'dashboard.view',
  'admin.manage',
  'export.create',
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export const ROLES = [
  'VIEWER',
  'PRICING_EDITOR',
  'PRICING_MANAGER',
  'AUDITOR',
  'ADMIN',
  'SYSTEM',
] as const;

export type Role = (typeof ROLES)[number];

/** true nếu có ít nhất một quyền trong danh sách (danh sách rỗng = không yêu cầu quyền). */
export function hasAny(granted: readonly string[], required: readonly Permission[]): boolean {
  return required.length === 0 || required.some((p) => granted.includes(p));
}
