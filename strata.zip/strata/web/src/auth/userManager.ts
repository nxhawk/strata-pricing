import { UserManager, WebStorageStateStore } from 'oidc-client-ts';

import { env } from '@/config/env';

export const CALLBACK_PATH = '/auth/callback';

/**
 * OIDC Authorization Code + PKCE với Keycloak (SPEC §16.2).
 *
 * - access token 5 phút, tự làm mới trước khi hết hạn bằng refresh token
 *   (automaticSilentRenew) nên người dùng không bị đá ra màn hình đăng nhập.
 * - Token lưu trong sessionStorage (mất khi đóng tab); không dùng cookie nên
 *   không phát sinh CSRF.
 */
export const userManager = new UserManager({
  authority: env.oidcAuthority,
  client_id: env.oidcClientId,
  redirect_uri: `${window.location.origin}${CALLBACK_PATH}`,
  post_logout_redirect_uri: `${window.location.origin}/`,
  response_type: 'code',
  scope: 'openid profile email',
  automaticSilentRenew: true,
  accessTokenExpiringNotificationTimeInSeconds: 60,
  monitorSession: false,
  userStore: new WebStorageStateStore({ store: window.sessionStorage }),
});

export interface SigninState {
  returnTo: string;
}

export function currentPath(): string {
  const { pathname, search, hash } = window.location;
  return pathname === CALLBACK_PATH ? '/' : `${pathname}${search}${hash}`;
}
