import { useEffect, useRef, type ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { hasAuthParams, useAuth } from 'react-oidc-context';

import { FullPageMessage } from '@/components/states/FullPageMessage';

import { currentPath, type SigninState } from './userManager';

/**
 * Chặn toàn bộ ứng dụng cho tới khi đăng nhập xong (mọi màn hình đều cần
 * đăng nhập). Chưa đăng nhập -> chuyển sang Keycloak, giữ lại URL để quay về.
 */
export function AuthGate({ children }: { children: ReactNode }) {
  const auth = useAuth();
  const { t } = useTranslation();
  const redirected = useRef(false);

  useEffect(() => {
    if (
      !hasAuthParams() &&
      !auth.isAuthenticated &&
      !auth.activeNavigator &&
      !auth.isLoading &&
      !auth.error &&
      !redirected.current
    ) {
      redirected.current = true;
      const state: SigninState = { returnTo: currentPath() };
      void auth.signinRedirect({ state });
    }
  }, [auth]);

  if (auth.error) {
    return (
      <FullPageMessage
        tone="danger"
        message={t('auth.signInError')}
        action={{
          label: t('auth.signInAgain'),
          onClick: () => void auth.signinRedirect({ state: { returnTo: currentPath() } }),
        }}
      />
    );
  }
  if (auth.activeNavigator === 'signoutRedirect') {
    return <FullPageMessage message={t('auth.signingOut')} busy />;
  }
  if (!auth.isAuthenticated) {
    return <FullPageMessage message={t('auth.signingIn')} busy />;
  }
  return <>{children}</>;
}
