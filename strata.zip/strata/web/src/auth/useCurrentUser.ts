import { useCallback } from 'react';

import { useMe } from '@/api/me';

import { hasAny, type Permission } from './permissions';

/** Người dùng hiện tại (từ GET /query/me) và helper kiểm tra quyền. */
export function useCurrentUser() {
  const query = useMe();
  const permissions = query.data?.permissions;
  const canAny = useCallback(
    (required: readonly Permission[]) => hasAny(permissions ?? [], required),
    [permissions],
  );
  return { ...query, me: query.data, canAny };
}
