import vi from '@/i18n/locales/vi.json';

import { isApiError } from './problem';

type ErrorCode = keyof typeof vi.errors;
export type ErrorMessageKey = `errors.${ErrorCode}`;

const KNOWN = new Set(Object.keys(vi.errors));

/** Khoá i18n của thông điệp lỗi theo mã API (UX §12.3); mã lạ -> INTERNAL. */
export function errorMessageKey(error: unknown): ErrorMessageKey {
  if (isApiError(error) && KNOWN.has(error.code)) return `errors.${error.code as ErrorCode}`;
  return 'errors.INTERNAL';
}
