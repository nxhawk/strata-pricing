/** Lỗi API theo RFC 9457 (application/problem+json) - SPEC §13.1, §13.4. */
export interface FieldError {
  field: string;
  code: string;
  message: string;
}

export interface Problem {
  type?: string;
  title?: string;
  status: number;
  detail?: string;
  instance?: string;
  code: string;
  requestId?: string;
  errors?: FieldError[];
  details?: Record<string, unknown>;
}

/** Mã lỗi phía client khi không gọi được server. */
export const NETWORK_ERROR = 'NETWORK';

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly requestId?: string;
  readonly fieldErrors: FieldError[];
  readonly details: Record<string, unknown>;

  constructor(problem: Problem) {
    super(problem.detail ?? problem.title ?? problem.code);
    this.name = 'ApiError';
    this.status = problem.status;
    this.code = problem.code;
    this.requestId = problem.requestId;
    this.fieldErrors = problem.errors ?? [];
    this.details = problem.details ?? {};
  }

  /** Lỗi có thể thử lại (mạng, 5xx, 429). */
  get retryable(): boolean {
    return this.code === NETWORK_ERROR || this.status >= 500 || this.status === 429;
  }

  static async fromResponse(res: Response): Promise<ApiError> {
    const requestId = res.headers.get('X-Request-Id') ?? undefined;
    const type = res.headers.get('Content-Type') ?? '';
    if (type.includes('json')) {
      try {
        const body = (await res.json()) as Partial<Problem>;
        if (body && typeof body.code === 'string') {
          return new ApiError({
            ...body,
            status: body.status ?? res.status,
            code: body.code,
            requestId: body.requestId ?? requestId,
          });
        }
      } catch {
        // thân không phải JSON hợp lệ - rơi xuống nhánh mặc định
      }
    }
    return new ApiError({ status: res.status, code: fallbackCode(res.status), requestId });
  }

  static network(cause: unknown): ApiError {
    const err = new ApiError({ status: 0, code: NETWORK_ERROR });
    (err as { cause?: unknown }).cause = cause;
    return err;
  }
}

function fallbackCode(status: number): string {
  if (status === 401) return 'UNAUTHENTICATED';
  if (status === 403) return 'FORBIDDEN';
  if (status === 404) return 'NOT_FOUND';
  if (status === 429) return 'RATE_LIMITED';
  if (status === 503 || status === 502 || status === 504) return 'UNAVAILABLE';
  return 'INTERNAL';
}

export function isApiError(e: unknown): e is ApiError {
  return e instanceof ApiError;
}
