import { currentPath, userManager } from '@/auth/userManager';

import { ApiClient, type TokenSource } from './client';

const oidcTokens: TokenSource = {
  async getAccessToken() {
    const user = await userManager.getUser();
    if (!user) return null;
    if (!user.expired) return user.access_token;
    return this.renew();
  },
  async renew() {
    try {
      const user = await userManager.signinSilent();
      return user?.access_token ?? null;
    } catch {
      return null;
    }
  },
  onUnauthenticated() {
    void userManager.signinRedirect({ state: { returnTo: currentPath() } });
  },
};

/** Client dùng chung của ứng dụng. */
export const api = new ApiClient(oidcTokens);

export { ApiError, isApiError } from './problem';
