import { ApiClient, type TokenSource } from './client';
import { ApiError } from './problem';

function jsonResponse(status: number, body: unknown, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...headers },
  });
}

function makeTokens(overrides: Partial<TokenSource> = {}): TokenSource {
  return {
    getAccessToken: vi.fn().mockResolvedValue('old'),
    renew: vi.fn().mockResolvedValue('new'),
    onUnauthenticated: vi.fn(),
    ...overrides,
  };
}

describe('ApiClient', () => {
  it('gắn Bearer token và trả JSON', async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(200, { ok: true }));
    const client = new ApiClient(makeTokens(), fetchMock);

    await expect(client.get('/api/v1/query/me')).resolves.toEqual({ ok: true });
    const headers = fetchMock.mock.calls[0]?.[1]?.headers as Headers;
    expect(headers.get('Authorization')).toBe('Bearer old');
  });

  it('401 -> làm mới token một lần rồi gửi lại', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(jsonResponse(401, { status: 401, code: 'UNAUTHENTICATED' }))
      .mockResolvedValueOnce(jsonResponse(200, { ok: 1 }));
    const tokens = makeTokens();
    const client = new ApiClient(tokens, fetchMock);

    await expect(client.get('/x')).resolves.toEqual({ ok: 1 });
    expect(tokens.renew).toHaveBeenCalledTimes(1);
    const retried = fetchMock.mock.calls[1]?.[1]?.headers as Headers;
    expect(retried.get('Authorization')).toBe('Bearer new');
    expect(tokens.onUnauthenticated).not.toHaveBeenCalled();
  });

  it('401 khi không làm mới được -> báo onUnauthenticated', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(jsonResponse(401, { status: 401, code: 'UNAUTHENTICATED' }));
    const tokens = makeTokens({ renew: vi.fn().mockResolvedValue(null) });
    const client = new ApiClient(tokens, fetchMock);

    await expect(client.get('/x')).rejects.toMatchObject({ status: 401, code: 'UNAUTHENTICATED' });
    expect(tokens.onUnauthenticated).toHaveBeenCalledTimes(1);
  });

  it('nhiều 401 đồng thời chỉ làm mới token một lần', async () => {
    let calls = 0;
    const fetchMock = vi.fn().mockImplementation((_p: string, init: RequestInit) => {
      calls += 1;
      const auth = (init.headers as Headers).get('Authorization');
      return Promise.resolve(
        auth === 'Bearer new'
          ? jsonResponse(200, {})
          : jsonResponse(401, { status: 401, code: 'UNAUTHENTICATED' }),
      );
    });
    const tokens = makeTokens();
    const client = new ApiClient(tokens, fetchMock);

    await Promise.all([client.get('/a'), client.get('/b'), client.get('/c')]);
    expect(tokens.renew).toHaveBeenCalledTimes(1);
    expect(calls).toBe(6);
  });

  it('chuyển problem+json thành ApiError kèm requestId', async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      jsonResponse(403, {
        status: 403,
        code: 'SUPPLIER_OUT_OF_SCOPE',
        requestId: 'r-1',
        detail: 'x',
      }),
    );
    const client = new ApiClient(makeTokens(), fetchMock);

    const err = await client.get('/x').catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err).toMatchObject({ status: 403, code: 'SUPPLIER_OUT_OF_SCOPE', requestId: 'r-1' });
  });

  it('lỗi mạng -> ApiError NETWORK có thể thử lại', async () => {
    const fetchMock = vi.fn().mockRejectedValue(new TypeError('Failed to fetch'));
    const client = new ApiClient(makeTokens(), fetchMock);

    const err = (await client.get('/x').catch((e: unknown) => e)) as ApiError;
    expect(err.code).toBe('NETWORK');
    expect(err.retryable).toBe(true);
  });

  it('thân không phải JSON -> mã theo status, lấy X-Request-Id từ header', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(
        new Response('bad gateway', { status: 502, headers: { 'X-Request-Id': 'gw-9' } }),
      );
    const client = new ApiClient(makeTokens(), fetchMock);

    await expect(client.get('/x')).rejects.toMatchObject({
      code: 'UNAVAILABLE',
      requestId: 'gw-9',
    });
  });
});
