import { useQuery } from '@tanstack/react-query';

import type { Permission, Role } from '@/auth/permissions';

import { api } from './index';

/** GET /api/v1/query/me (UC-01). */
export interface Me {
  id: string;
  username: string;
  name: string;
  email?: string;
  kind: 'user' | 'service';
  roles: Role[];
  supplierScope: string[];
  allSuppliers: boolean;
  permissions: Permission[];
}

export const meQueryKey = ['me'] as const;

export function fetchMe(): Promise<Me> {
  return api.get<Me>('/api/v1/query/me');
}

export function useMe() {
  return useQuery({ queryKey: meQueryKey, queryFn: fetchMe, staleTime: 5 * 60_000 });
}
