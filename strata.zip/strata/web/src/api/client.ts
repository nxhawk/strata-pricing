import { ApiError } from './problem';

/** Cách lấy/làm mới token - tách khỏi client để test và để đổi IdP không ảnh hưởng API. */
export interface TokenSource {
  /** Token hiện tại (đã tự làm mới nếu hết hạn), null nếu chưa đăng nhập. */
  getAccessToken(): Promise<string | null>;
  /** Ép làm mới token; null nếu không làm mới được (phiên đã hết). */
  renew(): Promise<string | null>;
  /** Gọi khi không thể xác thực nữa (chuyển sang đăng nhập lại). */
  onUnauthenticated(): void;
}

export interface RequestOptions extends Omit<RequestInit, 'body'> {
  /** Thân JSON; client tự serialize và đặt Content-Type. */
  json?: unknown;
}

/**
 * HTTP client cho Command API và Query API (SPEC §13.1):
 * gắn Bearer token, thử lại một lần với token mới khi gặp 401, chuyển lỗi
 * problem+json thành ApiError.
 */
export class ApiClient {
  private renewing: Promise<string | null> | null = null;

  constructor(
    private readonly tokens: TokenSource,
    private readonly fetchImpl: typeof fetch = (...args) => fetch(...args),
  ) {}

  async request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
    const send = (token: string | null) => this.send(path, opts, token);

    let res = await send(await this.tokens.getAccessToken());
    if (res.status === 401) {
      const fresh = await this.renewOnce();
      if (fresh) res = await send(fresh);
    }
    if (res.status === 401) {
      this.tokens.onUnauthenticated();
    }
    if (!res.ok) throw await ApiError.fromResponse(res);
    if (res.status === 204) return undefined as T;
    return (await res.json()) as T;
  }

  get<T>(path: string, opts?: RequestOptions) {
    return this.request<T>(path, { ...opts, method: 'GET' });
  }

  post<T>(path: string, json?: unknown, opts?: RequestOptions) {
    return this.request<T>(path, { ...opts, method: 'POST', json });
  }

  private async send(path: string, opts: RequestOptions, token: string | null): Promise<Response> {
    const { json, headers, ...rest } = opts;
    const h = new Headers(headers);
    h.set('Accept', 'application/json');
    if (token) h.set('Authorization', `Bearer ${token}`);
    if (json !== undefined) h.set('Content-Type', 'application/json');
    try {
      return await this.fetchImpl(path, {
        ...rest,
        headers: h,
        body: json !== undefined ? JSON.stringify(json) : undefined,
      });
    } catch (e) {
      throw ApiError.network(e);
    }
  }

  /** Gộp nhiều request 401 đồng thời thành một lần làm mới token. */
  private renewOnce(): Promise<string | null> {
    this.renewing ??= this.tokens.renew().finally(() => {
      this.renewing = null;
    });
    return this.renewing;
  }
}
