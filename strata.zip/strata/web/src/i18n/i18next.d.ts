import 'i18next';

import type vi from './locales/vi.json';

// Khoá dịch được kiểm tra kiểu: t('nav.prices') hợp lệ, t('nav.typo') lỗi biên dịch.
declare module 'i18next' {
  interface CustomTypeOptions {
    defaultNS: 'translation';
    resources: { translation: typeof vi };
  }
}
