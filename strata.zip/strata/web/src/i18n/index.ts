import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import en from './locales/en.json';
import vi from './locales/vi.json';

/** Ngôn ngữ hỗ trợ (NFR-17). Tiếng Việt là mặc định. */
export const SUPPORTED_LANGUAGES = ['vi', 'en'] as const;
export type Language = (typeof SUPPORTED_LANGUAGES)[number];
export const DEFAULT_LANGUAGE: Language = 'vi';

export const resources = {
  vi: { translation: vi },
  en: { translation: en },
} as const;

export function isLanguage(v: unknown): v is Language {
  return typeof v === 'string' && (SUPPORTED_LANGUAGES as readonly string[]).includes(v);
}

export function initI18n(language: Language = DEFAULT_LANGUAGE) {
  if (!i18n.isInitialized) {
    void i18n.use(initReactI18next).init({
      resources,
      lng: language,
      fallbackLng: DEFAULT_LANGUAGE,
      interpolation: { escapeValue: false }, // React đã escape
      returnNull: false,
    });
  }
  document.documentElement.lang = language;
  return i18n;
}

export function setLanguage(language: Language) {
  void i18n.changeLanguage(language);
  document.documentElement.lang = language;
}

export default i18n;
