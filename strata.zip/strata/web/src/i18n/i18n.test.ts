import en from './locales/en.json';
import vi from './locales/vi.json';

function keys(obj: object, prefix = ''): string[] {
  return Object.entries(obj).flatMap(([k, v]) =>
    v !== null && typeof v === 'object' ? keys(v, `${prefix}${k}.`) : [`${prefix}${k}`],
  );
}

function placeholders(s: string): string[] {
  return [...s.matchAll(/{{\s*(\w+)\s*}}/g)].map((m) => m[1] ?? '').sort();
}

describe('i18n resources', () => {
  it('en có đúng bộ khoá như vi', () => {
    expect(keys(en).sort()).toEqual(keys(vi).sort());
  });

  it('các bản dịch giữ nguyên placeholder', () => {
    const get = (o: object, path: string) =>
      path.split('.').reduce<unknown>((acc, k) => (acc as Record<string, unknown>)[k], o) as string;
    for (const k of keys(vi)) {
      expect(placeholders(get(en, k)), k).toEqual(placeholders(get(vi, k)));
    }
  });
});
