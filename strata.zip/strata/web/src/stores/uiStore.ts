import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

import { DEFAULT_LANGUAGE, type Language } from '@/i18n';

export type Density = 'compact' | 'default' | 'comfortable';

interface UiState {
  /** Lựa chọn của người dùng cho sidebar; null = theo độ rộng màn hình (UX §4.3). */
  sidebarCollapsedPref: boolean | null;
  language: Language;
  density: Density;
  setSidebarCollapsedPref: (v: boolean | null) => void;
  setLanguage: (l: Language) => void;
  setDensity: (d: Density) => void;
}

/**
 * Tuỳ chọn giao diện của người dùng, lưu localStorage (chỉ là tiện ích theo
 * trình duyệt; mất dữ liệu cũng không sao). Đồng bộ lên server
 * (/users/me/preferences - SPEC §15.5) ở phase sau.
 */
export const useUiStore = create<UiState>()(
  persist(
    (set) => ({
      sidebarCollapsedPref: null,
      language: DEFAULT_LANGUAGE,
      density: 'default',
      setSidebarCollapsedPref: (v) => set({ sidebarCollapsedPref: v }),
      setLanguage: (language) => set({ language }),
      setDensity: (density) => set({ density }),
    }),
    {
      name: 'strata.ui',
      version: 1,
      // createJSONStorage tự bỏ qua khi localStorage không dùng được (private mode...).
      storage: createJSONStorage(() => localStorage),
    },
  ),
);
