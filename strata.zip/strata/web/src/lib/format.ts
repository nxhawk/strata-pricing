/**
 * Định dạng hiển thị theo UX §13 (locale vi-VN, múi giờ Asia/Ho_Chi_Minh).
 * Số tiền từ API là chuỗi thập phân ("118000.0000", SPEC §13.1): chỉ chuyển
 * sang number ở bước hiển thị, không tính toán tiền trên number.
 */
export const LOCALE = 'vi-VN';
export const TIME_ZONE = 'Asia/Ho_Chi_Minh';

const intFmt = new Intl.NumberFormat(LOCALE, { maximumFractionDigits: 0 });
const pctFmt = new Intl.NumberFormat(LOCALE, {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
});
const dateFmt = new Intl.DateTimeFormat(LOCALE, {
  timeZone: TIME_ZONE,
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
});
const timeFmt = new Intl.DateTimeFormat(LOCALE, {
  timeZone: TIME_ZONE,
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});

type Numeric = number | string;
const toNumber = (v: Numeric) => (typeof v === 'number' ? v : Number(v));

/** 1024318 -> "1.024.318" */
export function formatInteger(v: Numeric): string {
  return intFmt.format(toNumber(v));
}

/** "118000.0000" -> "118.000 ₫" (withSymbol=false trong grid: "118.000") */
export function formatVnd(v: Numeric, withSymbol = true): string {
  const s = intFmt.format(Math.round(toNumber(v)));
  return withSymbol ? `${s} ₫` : s;
}

/** 12.38 -> "▲ 12,4%", -3 -> "▼ 3,0%", 0 -> "0,0%" */
export function formatChangePct(v: Numeric): string {
  const n = toNumber(v);
  if (n === 0 || Object.is(n, -0)) return `${pctFmt.format(0)}%`;
  return `${n > 0 ? '▲' : '▼'} ${pctFmt.format(Math.abs(n))}%`;
}

/** +12350 -> "+12.350" */
export function formatDelta(v: Numeric): string {
  const n = toNumber(v);
  const s = intFmt.format(Math.abs(n));
  if (n > 0) return `+${s}`;
  if (n < 0) return `-${s}`;
  return s;
}

/** -> "01/12/2026" */
export function formatDate(d: Date | string): string {
  return dateFmt.format(new Date(d));
}

/** -> "15/03/2026 14:20" */
export function formatDateTime(d: Date | string): string {
  const date = new Date(d);
  return `${dateFmt.format(date)} ${timeFmt.format(date)}`;
}

/** Hàm dịch tối giản (tương thích i18next TFunction) để lib không phụ thuộc React. */
export type Translate = (
  key: `time.${'justNow' | 'minutesAgo' | 'today' | 'yesterday'}`,
  opts?: Record<string, unknown>,
) => string;

/**
 * Thời gian tương đối (UX §13): "vừa xong", "x phút trước", "09:02 hôm nay",
 * "Hôm qua 16:40", còn lại ngày giờ đầy đủ. Chuỗi lấy từ i18n (khoá time.*).
 */
export function formatRelative(d: Date | string, t: Translate, now: Date = new Date()): string {
  const date = new Date(d);
  const diffMs = now.getTime() - date.getTime();
  if (diffMs >= 0 && diffMs < 60_000) return t('time.justNow');
  if (diffMs >= 0 && diffMs < 3_600_000) {
    return t('time.minutesAgo', { count: Math.floor(diffMs / 60_000) });
  }
  const day = (x: Date) => dateFmt.format(x);
  const yesterday = new Date(now.getTime() - 86_400_000);
  if (day(date) === day(now)) return t('time.today', { time: timeFmt.format(date) });
  if (day(date) === day(yesterday)) return t('time.yesterday', { time: timeFmt.format(date) });
  return formatDateTime(date);
}
