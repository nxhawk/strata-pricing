import {
  formatChangePct,
  formatDate,
  formatDateTime,
  formatDelta,
  formatInteger,
  formatRelative,
  formatVnd,
} from './format';
import i18n, { initI18n } from '@/i18n';

beforeAll(() => {
  initI18n('vi');
});

describe('format (UX §13)', () => {
  it('số nguyên dùng dấu chấm phân cách nghìn', () => {
    expect(formatInteger(1024318)).toBe('1.024.318');
  });

  it('tiền VND từ chuỗi thập phân', () => {
    expect(formatVnd('118000.0000')).toBe('118.000 ₫');
    expect(formatVnd('118000.0000', false)).toBe('118.000');
  });

  it('phần trăm có mũi tên và 1 chữ số lẻ', () => {
    expect(formatChangePct(12.38)).toBe('▲ 12,4%');
    expect(formatChangePct('-3')).toBe('▼ 3,0%');
    expect(formatChangePct(0)).toBe('0,0%');
  });

  it('chênh lệch có dấu', () => {
    expect(formatDelta(12350)).toBe('+12.350');
    expect(formatDelta(-500)).toBe('-500');
  });

  it('ngày giờ theo múi giờ Việt Nam', () => {
    expect(formatDate('2026-11-30T17:00:00Z')).toBe('01/12/2026');
    expect(formatDateTime('2026-03-15T07:20:00Z')).toBe('15/03/2026 14:20');
  });

  it('thời gian tương đối', () => {
    const t = i18n.t.bind(i18n);
    const now = new Date('2026-10-30T03:00:00Z'); // 10:00 giờ VN
    expect(formatRelative(new Date(now.getTime() - 6_000), t, now)).toBe('vừa xong');
    expect(formatRelative(new Date(now.getTime() - 5 * 60_000), t, now)).toBe('5 phút trước');
    expect(formatRelative('2026-10-30T01:02:00Z', t, now)).toBe('08:02 hôm nay');
    expect(formatRelative('2026-10-29T09:40:00Z', t, now)).toBe('Hôm qua 16:40');
    expect(formatRelative('2026-10-01T09:40:00Z', t, now)).toBe('01/10/2026 16:40');
  });
});
