import { Inbox, type LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';

import './states.css';

interface Props {
  title: string;
  body?: string;
  icon?: LucideIcon;
  /** Đúng MỘT hành động tiếp theo (UX §7.5). */
  action?: ReactNode;
}

export function EmptyState({ title, body, icon: Icon = Inbox, action }: Props) {
  return (
    <div className="state">
      <Icon className="state__icon" size={40} strokeWidth={1.5} aria-hidden="true" />
      <h2 className="state__title">{title}</h2>
      {body && <p className="state__body">{body}</p>}
      {action && <div className="state__action">{action}</div>}
    </div>
  );
}
