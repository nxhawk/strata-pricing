import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import './states.css';

const SLOW_AFTER_MS = 10_000;

/** Trạng thái đang tải (UX §7.5): skeleton; sau 10 giây báo "vẫn đang tải". */
export function LoadingState({ rows = 3 }: { rows?: number }) {
  const { t } = useTranslation();
  const [slow, setSlow] = useState(false);
  useEffect(() => {
    const id = window.setTimeout(() => setSlow(true), SLOW_AFTER_MS);
    return () => window.clearTimeout(id);
  }, []);

  return (
    <div className="state" role="status" aria-busy="true">
      <span className="visually-hidden">{t('states.loading')}</span>
      <div className="skeleton" aria-hidden="true">
        {Array.from({ length: rows }, (_, i) => (
          <div key={i} className="skeleton__line" style={{ width: `${90 - i * 15}%` }} />
        ))}
      </div>
      {slow && <p className="state__hint">{t('states.loadingSlow')}</p>}
    </div>
  );
}
