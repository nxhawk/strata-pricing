import './states.css';

interface Props {
  message: string;
  busy?: boolean;
  tone?: 'neutral' | 'danger';
  action?: { label: string; onClick: () => void };
}

/** Màn hình chờ/lỗi toàn trang (trước khi có layout, ví dụ lúc đăng nhập). */
export function FullPageMessage({ message, busy = false, tone = 'neutral', action }: Props) {
  return (
    <div className="full-page" role={tone === 'danger' ? 'alert' : 'status'} aria-busy={busy}>
      <img src="/favicon.svg" alt="" width={48} height={48} />
      <p className={`full-page__msg full-page__msg--${tone}`}>{message}</p>
      {action && (
        <button type="button" className="btn btn--primary" onClick={action.onClick}>
          {action.label}
        </button>
      )}
    </div>
  );
}
