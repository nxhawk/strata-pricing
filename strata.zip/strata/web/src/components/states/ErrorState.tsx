import { RefreshCw, TriangleAlert } from 'lucide-react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';

import { isApiError } from '@/api/problem';
import { errorMessageKey } from '@/api/errorMessage';

import './states.css';

interface Props {
  error: unknown;
  onRetry?: () => void;
}

/**
 * Trạng thái lỗi (UX §7.5): nói rõ dữ liệu không bị ảnh hưởng, luôn có nút
 * Thử lại và mã tham chiếu (request id) để gửi hỗ trợ.
 */
export function ErrorState({ error, onRetry }: Props) {
  const { t } = useTranslation();
  const [copied, setCopied] = useState(false);
  const requestId = isApiError(error) ? error.requestId : undefined;

  const copy = async () => {
    if (!requestId) return;
    try {
      await navigator.clipboard.writeText(requestId);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="state" role="alert">
      <TriangleAlert
        className="state__icon state__icon--danger"
        size={40}
        strokeWidth={1.5}
        aria-hidden="true"
      />
      <h2 className="state__title">{t('states.errorTitle')}</h2>
      <p className="state__body">{t(errorMessageKey(error))}</p>
      {requestId && (
        <p className="state__ref">
          {t('states.requestId')}: <span className="mono">{requestId}</span>{' '}
          <button type="button" className="btn btn--ghost btn--sm" onClick={() => void copy()}>
            {copied ? t('states.copied') : t('states.copy')}
          </button>
        </p>
      )}
      {onRetry && (
        <div className="state__action">
          <button type="button" className="btn btn--primary" onClick={onRetry}>
            <RefreshCw size={16} aria-hidden="true" />
            {t('states.retry')}
          </button>
        </div>
      )}
    </div>
  );
}
