import { ShieldOff } from 'lucide-react';
import { useTranslation } from 'react-i18next';

import { EmptyState } from './EmptyState';

export function ForbiddenState() {
  const { t } = useTranslation();
  return (
    <EmptyState
      icon={ShieldOff}
      title={t('states.forbiddenTitle')}
      body={t('states.forbiddenBody')}
    />
  );
}
