import type { ReactNode } from 'react';

import './PageHeader.css';

interface Props {
  title: string;
  description?: string;
  actions?: ReactNode;
}

/** Tiêu đề trang (UX §7.6 PageHeader). Mỗi trang có đúng một h1. */
export function PageHeader({ title, description, actions }: Props) {
  return (
    <header className="page-header">
      <div>
        <h1 className="page-header__title">{title}</h1>
        {description && <p className="page-header__desc">{description}</p>}
      </div>
      {actions && <div className="page-header__actions">{actions}</div>}
    </header>
  );
}
