import { LicenseManager } from 'ag-grid-enterprise';

import { env } from '@/config/env';

import './ag-theme-strata.css';

let done = false;

/**
 * Cấu hình AG Grid một lần cho cả ứng dụng: license Enterprise (SPEC §23.1)
 * và theme Strata. Gọi trong module của component grid (PH-05), không gọi ở
 * main.tsx để không kéo AG Grid vào các trang không cần.
 */
export function setupAgGrid(): void {
  if (done) return;
  if (env.agGridLicenseKey) {
    LicenseManager.setLicenseKey(env.agGridLicenseKey);
  }
  done = true;
}
