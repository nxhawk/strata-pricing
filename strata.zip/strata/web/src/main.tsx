import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import { App } from '@/app/App';
import { initI18n } from '@/i18n';
import { useUiStore } from '@/stores/uiStore';

// Font tự host (UX §6.3): Inter có đủ dấu tiếng Việt; JetBrains Mono cho SKU, mã lỗi.
import '@fontsource-variable/inter';
import '@fontsource/jetbrains-mono/400.css';
import './styles/tokens.generated.css';
import './styles/global.css';

initI18n(useUiStore.getState().language);

const root = document.getElementById('root');
if (!root) throw new Error('#root not found');

createRoot(root).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
