/**
 * Cấu hình runtime của frontend, đọc một lần từ biến VITE_* (xem .env.example).
 * Giá trị mặc định khớp docker-compose local nên chạy được ngay không cần .env.
 */
export interface AppEnv {
  oidcAuthority: string;
  oidcClientId: string;
  grafanaUrl: string;
  agGridLicenseKey: string;
}

function read(name: keyof ImportMetaEnv, fallback: string): string {
  const v = import.meta.env[name];
  return typeof v === 'string' && v.trim() !== '' ? v.trim() : fallback;
}

export const env: AppEnv = Object.freeze({
  oidcAuthority: read('VITE_OIDC_AUTHORITY', 'http://localhost:8081/realms/strata'),
  oidcClientId: read('VITE_OIDC_CLIENT_ID', 'web'),
  grafanaUrl: read('VITE_GRAFANA_URL', 'http://localhost:3000'),
  agGridLicenseKey: read('VITE_AG_GRID_LICENSE_KEY', ''),
});
