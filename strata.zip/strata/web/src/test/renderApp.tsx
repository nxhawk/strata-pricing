import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router-dom';

import { meQueryKey, type Me } from '@/api/me';
import { ROUTER_FUTURE, routes } from '@/app/router';
import type { Permission, Role } from '@/auth/permissions';

/** Quyền theo vai trò - khớp ma trận backend (internal/domain/identity/permission.go). */
export const PERMS_BY_ROLE: Record<Role, Permission[]> = {
  VIEWER: ['price.view', 'price.history', 'export.create'],
  PRICING_EDITOR: [
    'price.view',
    'price.history',
    'export.create',
    'version.view',
    'file.upload',
    'draft.edit',
    'version.submit',
    'version.discard',
  ],
  PRICING_MANAGER: [
    'price.view',
    'price.history',
    'export.create',
    'version.view',
    'file.upload',
    'draft.edit',
    'version.submit',
    'version.discard',
    'version.approve',
    'version.rollback',
    'price.hotfix',
    'audit.view',
    'dashboard.view',
  ],
  AUDITOR: [
    'price.view',
    'price.history',
    'export.create',
    'version.view',
    'audit.view',
    'dashboard.view',
  ],
  ADMIN: [
    'price.view',
    'price.history',
    'export.create',
    'version.view',
    'audit.view',
    'dashboard.view',
    'admin.manage',
  ],
  SYSTEM: ['price.view', 'price.history'],
};

export function makeMe(role: Role, overrides: Partial<Me> = {}): Me {
  return {
    id: `u-${role}`,
    username: role.toLowerCase(),
    name: 'Minh Trần',
    kind: 'user',
    roles: [role],
    supplierScope: ['ACME', 'BMI'],
    allSuppliers: false,
    permissions: PERMS_BY_ROLE[role],
    ...overrides,
  };
}

/** Render toàn bộ router với người dùng đã đăng nhập (bỏ qua OIDC). */
export function renderApp(me: Me, path = '/prices') {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false, staleTime: Infinity } },
  });
  queryClient.setQueryData(meQueryKey, me);
  const router = createMemoryRouter(routes, { initialEntries: [path], future: ROUTER_FUTURE });
  const utils = render(
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} future={{ v7_startTransition: true }} />
    </QueryClientProvider>,
  );
  return { ...utils, router, queryClient };
}
