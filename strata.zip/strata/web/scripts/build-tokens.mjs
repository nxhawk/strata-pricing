// Sinh src/styles/tokens.generated.css từ src/styles/tokens.json (UX §17.2).
//
// Quy tắc đặt tên: đường dẫn JSON -> CSS custom property kebab-case.
//   color.primary.600      -> --color-primary-600
//   grid.rowHeight.compact -> --grid-row-height-compact
// Số trong nhóm kích thước được thêm "px"; "weight" giữ nguyên số.
//
// Chạy: npm run tokens (tự chạy trước dev/build). Thêm --check để chỉ kiểm tra
// file sinh ra có khớp JSON không (dùng trong CI / test).
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const SRC = join(root, 'src/styles/tokens.json');
const OUT = join(root, 'src/styles/tokens.generated.css');

const kebab = (s) => s.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
const UNITLESS = new Set(['weight']);

function flatten(obj, path = []) {
  return Object.entries(obj).flatMap(([key, value]) => {
    if (key.startsWith('$')) return [];
    const next = [...path, key];
    if (value !== null && typeof value === 'object') return flatten(value, next);
    const v = typeof value === 'number' && !UNITLESS.has(key) ? `${value}px` : String(value);
    return [[`--${next.map(kebab).join('-')}`, v]];
  });
}

function render(tokens) {
  const lines = flatten(tokens).map(([k, v]) => `  ${k}: ${v};`);
  return [
    '/* FILE SINH TỰ ĐỘNG từ tokens.json bởi scripts/build-tokens.mjs - KHÔNG sửa tay. */',
    ':root {',
    ...lines,
    '}',
    '',
  ].join('\n');
}

const css = render(JSON.parse(readFileSync(SRC, 'utf8')));
if (process.argv.includes('--check')) {
  const current = readFileSync(OUT, 'utf8');
  if (current !== css) {
    console.error('tokens.generated.css lệch với tokens.json - chạy `npm run tokens`.');
    process.exit(1);
  }
} else {
  writeFileSync(OUT, css);
  console.warn(`tokens: đã sinh ${OUT.replace(root + '/', '')}`);
}
