/// <reference types="vitest/config" />
import { fileURLToPath, URL } from 'node:url';

import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// Dev server đóng vai API gateway khi chạy local: định tuyến /api/v1/commands
// -> command-svc và /api/v1/query -> query-svc (FLOW Luồng 1). Ghi đè đích bằng
// biến môi trường nếu chạy service ở cổng khác.
const commandTarget = process.env.STRATA_COMMAND_URL ?? 'http://localhost:8080';
const queryTarget = process.env.STRATA_QUERY_URL ?? 'http://localhost:8082';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  server: {
    port: 5173,
    strictPort: true, // redirect URI trong Keycloak cố định cổng 5173
    proxy: {
      '/api/v1/commands': { target: commandTarget, changeOrigin: true },
      '/api/v1/query': { target: queryTarget, changeOrigin: true },
    },
  },
  build: {
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: { react: ['react', 'react-dom', 'react-router-dom'] },
      },
    },
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    css: false,
    restoreMocks: true,
  },
});
