#!/usr/bin/env bash
# Khởi tạo Elasticsearch (SPEC §18.3 bước 3). Chạy BÊN TRONG container elasticsearch:
#   docker compose exec elasticsearch bash /usr/share/elasticsearch/strata-init/es-init.sh
#
#   templates/<tên>.json   -> PUT _index_template/<tên>
#   mappings/<index>_vN.json -> tạo index <index>_vN (nếu chưa có) + alias <index>
#
# Mapping thật (price_current_v1, price_history_v1...) được thêm ở PH-04.
set -euo pipefail

ES="${ES:-http://localhost:9200}"
DIR="$(cd "$(dirname "$0")" && pwd)"
shopt -s nullglob

put() { curl -fsS -X PUT "$ES/$1" -H 'Content-Type: application/json' --data-binary "@$2" > /dev/null; }

count=0
for f in "$DIR"/templates/*.json; do
  name="$(basename "$f" .json)"
  put "_index_template/$name" "$f"; echo "template $name"; count=$((count + 1))
done

for f in "$DIR"/mappings/*.json; do
  index="$(basename "$f" .json)"
  alias="${index%_v[0-9]*}"
  if curl -fs -o /dev/null "$ES/$index"; then
    echo "index    $index (đã có)"
  else
    put "$index" "$f"; echo "index    $index (tạo mới)"
  fi
  curl -fsS -X POST "$ES/_aliases" -H 'Content-Type: application/json' \
    -d "{\"actions\":[{\"add\":{\"index\":\"$index\",\"alias\":\"$alias\"}}]}" > /dev/null
  echo "alias    $alias -> $index"; count=$((count + 1))
done

[[ $count -eq 0 ]] && echo "Chưa có template/mapping nào trong deploy/es (sẽ có từ PH-04)."
exit 0
