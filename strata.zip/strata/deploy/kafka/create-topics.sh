#!/usr/bin/env bash
# Tạo/cập nhật topic theo topics.conf. Chạy BÊN TRONG container kafka:
#   docker compose exec kafka bash /etc/strata/kafka/create-topics.sh
set -euo pipefail

BOOTSTRAP="${BOOTSTRAP:-localhost:9092}"
CONF="${1:-/etc/strata/kafka/topics.conf}"
BIN=/opt/kafka/bin

while read -r topic partitions configs; do
  [[ -z "${topic}" || "${topic}" == \#* ]] && continue
  args=()
  IFS=',' read -ra kvs <<< "${configs:-}"
  for kv in "${kvs[@]}"; do [[ -n "$kv" ]] && args+=(--config "$kv"); done

  if "$BIN/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --describe --topic "$topic" > /dev/null 2>&1; then
    # Đã có: cập nhật config, tăng partition nếu cần (Kafka không cho giảm).
    [[ -n "${configs:-}" ]] && "$BIN/kafka-configs.sh" --bootstrap-server "$BOOTSTRAP" \
      --entity-type topics --entity-name "$topic" --alter --add-config "$configs" > /dev/null
    current=$("$BIN/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --describe --topic "$topic" \
      | sed -n 's/.*PartitionCount: *\([0-9]*\).*/\1/p' | head -1)
    if [[ -n "$current" && "$current" -lt "$partitions" ]]; then
      "$BIN/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --alter --topic "$topic" --partitions "$partitions"
    fi
    echo "updated  $topic (partitions=${current:-?}->$partitions)"
  else
    "$BIN/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --create --topic "$topic" \
      --partitions "$partitions" --replication-factor 1 "${args[@]}" > /dev/null
    echo "created  $topic (partitions=$partitions)"
  fi
done < "$CONF"
