# Hướng dẫn phát triển

Tài liệu này giúp người mới (hoặc chính bạn sau 3 tháng) biết **code nằm ở đâu, vì sao,
và thêm tính năng theo cách nào** mà không phá kiến trúc. Chi tiết thiết kế xem ARCH-001.

## 1. Backend - phân lớp hexagonal (ARCH §5.1)

```
cmd/<svc>/main.go          composition root: nạp config, tạo adapter, nối dây
      │
      ▼
adapter/in  (http, kafka, ws, job)  ──►  app (use case)  ──►  domain (thuần Go)
                                          │
                                          ▼ port (interface)
                                    adapter/out (postgres, oidc, es, s3, redis)

platform/  hạ tầng chung (config, log, otel, metrics, health, lifecycle) - không biết nghiệp vụ
```

| Lớp | Được import | Cấm import |
| --- | --- | --- |
| `internal/domain` | stdlib, shopspring/decimal | mọi lớp khác, net/http, pgx... |
| `internal/app` | domain, app/port | adapter, pgx, net/http, franz-go, ES client |
| `internal/adapter/in` | app, domain, platform | adapter/out |
| `internal/adapter/out` | app/port, domain, platform | adapter/in |
| `internal/platform` | stdlib, thư viện hạ tầng | domain, app, adapter |

Quy tắc được **kiểm tra tự động** bởi `depguard` trong `make lint` (`.golangci.yml`).
Vi phạm → lint đỏ, không cần nhớ.

### Thành phần dùng chung đã có

| Cần gì | Dùng | Ghi chú |
| --- | --- | --- |
| Khung một service mới | `service.Main(name, setup)` | Tự có config, log JSON, tracing, `/livez` `/readyz` `/metrics`, tắt êm |
| Router HTTP | `httpin.NewRouter(deps, "/api/v1/...", mount)` | Đủ chuỗi middleware chuẩn + xác thực JWT |
| Trả lỗi | trả `*apperr.Error` từ domain/app | Chỉ `problem` ánh xạ sang HTTP status (RFC 9457) |
| Người gọi hiện tại | `identity.FromContext(ctx)` | `Actor` có `Roles`, `SupplierScope`, `Can(perm)`, `CanAccessSupplier(code)` |
| Kiểm tra quyền mức route | `middleware.RequirePermission(identity.PermX)` | Supplier scope kiểm ở application layer |
| Log | `logger.InfoContext(ctx, ...)` | Luôn truyền `ctx` để có `trace_id`, `request_id`, `user_id` |
| Readiness | `k.Health.AddCheck(name, timeout, fn)` | Chỉ thêm phụ thuộc thật sự bắt buộc |
| Dọn tài nguyên | `k.OnStop(fn)` | Chạy theo thứ tự ngược khi tắt |
| Metric | `k.Metrics.Registerer` | Đã gắn nhãn `service` |

## 2. Công thức thêm tính năng (backend)

### Thêm một query/route mới (ví dụ `GET /api/v1/query/prices/{sku}`)

1. Domain/app: viết use case trong `internal/app/query/` (thuần, test bằng bảng).
2. Port cho hạ tầng cần thiết trong `internal/app/port/`, hiện thực ở `internal/adapter/out/...`.
3. Handler trong `internal/adapter/in/http/queryapi/`, đăng ký trong `API.Mount`.
4. Nối dây ở `cmd/query-svc/main.go`.
5. Test: unit cho use case, `httptest` cho handler (xem `queryapi/me_test.go`).

### Thêm một command (từ PH-03)

Như trên nhưng ở `internal/app/command/` + `commandapi`, kèm: idempotency, ghi outbox trong
cùng transaction (ARCH §5.3), JSON Schema của event trong `schemas/events/`.

### Thêm quyền mới

1. Thêm hằng `Perm...` và gán vào vai trò trong `internal/domain/identity/permission.go`
   (ma trận RBAC - nguồn sự thật duy nhất). Cập nhật `identity_test.go`.
2. Thêm cùng chuỗi vào `web/src/auth/permissions.ts` và `web/src/test/renderApp.tsx`.
3. Frontend nhận quyền qua `GET /query/me` - không tự suy từ role.

### Thêm migration + truy vấn SQL

```bash
make migrate-new NAME=create_supplier   # tạo db/migrations/0000N_create_supplier.sql
# viết -- +goose Up / -- +goose Down
make migrate
# viết truy vấn trong db/queries/<bảng>.sql với -- name: Xxx :one|:many|:exec
make sqlc                                # sinh internal/adapter/out/postgres/sqlcgen
```

Quy tắc (ARCH §7.5): chỉ expand → migrate → contract; không đổi tên cột một bước; code sinh
bởi sqlc được commit và `make sqlc-check` phải sạch.

### Thêm biến cấu hình

Thêm trường vào struct `Config` gần code dùng nó, tag `env:"TEN"` (+ `envDefault` hoặc
`,required`), cập nhật `docs/configuration.md` và `.env.example`.

## 3. Frontend (`web/`)

```
src/
  app/          App (providers), router.tsx (route + guard), navigation.ts (ROUTE_ACCESS + sidebar)
  auth/         OIDC (userManager, AuthGate), permissions, useCurrentUser, RequirePermission
  api/          ApiClient (Bearer, retry 401, problem+json → ApiError), me.ts, errorMessage.ts
  layout/       AppShell, Sidebar, TopBar, UserMenu, Breadcrumbs, GlobalSearch, RealtimeIndicator
  components/   PageHeader, Popover, states/ (Loading, Empty, Error, Forbidden, FullPage)
  pages/        mỗi màn hình SPEC §15.1 (PH-01 là khung)
  i18n/         vi.json (mặc định), en.json - khoá được kiểm tra kiểu
  lib/format.ts định dạng số/tiền/ngày vi-VN (UX §13)
  stores/       Zustand: tuỳ chọn giao diện
  styles/       tokens.json → tokens.generated.css, global.css
  grid/         theme ag-theme-strata + setup license (dùng từ PH-05)
```

### Quy ước

- **Quyền**: route và sidebar cùng đọc `ROUTE_ACCESS` trong `app/navigation.ts`. Thêm màn hình =
  thêm khoá vào `ROUTE_ACCESS`, route trong `router.tsx` (bọc `guard(...)`), mục `NAV_ITEMS` nếu
  cần hiện trên sidebar.
- **Microcopy**: mọi chuỗi hiển thị lấy từ `t('...')`. ESLint chặn chuỗi tiếng Việt cứng trong JSX;
  test đảm bảo `en.json` có đủ khoá và placeholder như `vi.json`.
- **Lỗi API**: bắt `ApiError`, hiển thị `t(errorMessageKey(err))` (UX §12.3); trạng thái lỗi toàn
  vùng dùng `<ErrorState error onRetry />` (có mã tham chiếu request id).
- **Màu/khoảng cách**: chỉ dùng CSS variable từ token. Sửa `src/styles/tokens.json` rồi
  `npm run tokens` (tự chạy trước `dev`/`build`; `npm run tokens:check` trong `npm run check`).
- **Server state** bằng TanStack Query; **UI state** bằng Zustand. Không lưu dữ liệu nghiệp vụ
  trong localStorage.
- Mỗi màn hình đủ 5 trạng thái: mặc định / đang tải / rỗng / lỗi / không có quyền (UX §17.4).

## 4. Kiểm thử

| Lớp | Lệnh | Ghi chú |
| --- | --- | --- |
| Go unit + HTTP | `make test` | `go test -race`; tên test `Test<Unit>_<Scenario>`, bảng test, không `sleep` |
| Go lint | `make lint` | gồm depguard (quy tắc lớp), gosec, errorlint, contextcheck... |
| SQL | `make sqlc-check` | code sinh khớp schema |
| Integration (từ PH-02) | testcontainers PG 16 | đặt trong `*_integration_test.go`, build tag `integration` |
| Frontend | `cd web && npm run check` | tokens, ESLint, tsc, Vitest + Testing Library |

## 5. Đăng nhập & token trong môi trường local

- Trình duyệt: Authorization Code + PKCE (client `web`), access token 5 phút, tự làm mới bằng
  refresh token trước khi hết hạn 60 giây. Token nằm trong `sessionStorage`.
- Backend tự verify JWT (chữ ký JWKS, `iss`, `aud=strata-api`, `exp`) ở mọi request - không tin
  gateway. Claim dùng: `sub`, `name`, `preferred_username`, `roles[]`, `supplier_scope[]`.
- `supplier_scope` lấy từ thuộc tính của **group** Keycloak (`supplier-ACME`, `supplier-ALL` = `*`).
  Gán NCC cho user = thêm user vào group tương ứng.
- Client `dev-cli` (password grant) **chỉ có ở realm local** để lấy token bằng `make token`.
