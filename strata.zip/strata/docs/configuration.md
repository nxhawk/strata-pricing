# Cấu hình (biến môi trường)

Mọi service đọc cấu hình từ biến môi trường một lần lúc khởi động (SPEC §17.8, 12-factor).
Thiếu biến bắt buộc hoặc giá trị sai → service thoát ngay (exit code 2) và in **toàn bộ**
biến còn thiếu, ví dụ:

```
command-svc: config: env: required environment variable "PG_DSN" is not set; required environment variable "OIDC_ISSUER" is not set
```

Khai báo nằm cạnh code dùng nó (struct `Config` với tag `env`), nên đây là nơi tra cứu
nhanh, còn nguồn sự thật là code.

## Chung cho mọi service (`internal/platform/service.Base`)

| Biến | Mặc định | Mô tả |
| --- | --- | --- |
| `HTTP_ADDR` | `:8080` | Cổng API công khai |
| `ADMIN_ADDR` | `:8090` | Cổng nội bộ: `/livez`, `/readyz`, `/metrics`, `/debug/pprof` |
| `LOG_LEVEL` | `info` | `debug` / `info` / `warn` / `error` |
| `LOG_FORMAT` | `json` | `json` (chuẩn) hoặc `text` (dễ đọc khi dev) |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | - | Ví dụ `http://jaeger:4318`. Trống → không gửi trace, nhưng log vẫn có `trace_id` |
| `OTEL_TRACES_SAMPLER_RATIO` | `1` | Tỉ lệ lấy mẫu trace, 0..1 |
| `SHUTDOWN_PRESTOP_DELAY` | `5s` | Chờ LB ngừng gửi request sau SIGTERM (ARCH §10.5); local đặt `0s`-`1s` |
| `SHUTDOWN_TIMEOUT` | `35s` | Thời gian tối đa để dừng các thành phần |

## Xác thực (command-svc, query-svc - `internal/adapter/out/oidc`)

| Biến | Mặc định | Mô tả |
| --- | --- | --- |
| `OIDC_ISSUER` | **bắt buộc** | Phải trùng claim `iss` (URL trình duyệt thấy): `http://localhost:8081/realms/strata` |
| `OIDC_AUDIENCE` | `strata-api` | Giá trị bắt buộc có trong claim `aud` |
| `OIDC_JWKS_URL` | - | URL tải khoá công khai. Đặt khi service thấy Keycloak qua địa chỉ khác trình duyệt (trong docker: `http://keycloak:8080/realms/strata/protocol/openid-connect/certs`). Trống → OIDC discovery từ issuer |

## PostgreSQL (command-svc - `internal/adapter/out/postgres`)

| Biến | Mặc định | Mô tả |
| --- | --- | --- |
| `PG_DSN` | **bắt buộc** | `postgres://app:app@localhost:5432/pricing?sslmode=disable` |
| `PG_MAX_CONNS` | `20` | pgxpool max (ARCH §7.2 khuyến nghị 10/pod khi có PgBouncer) |
| `PG_MIN_CONNS` | `2` | pgxpool min |

## query-svc

| Biến | Mặc định | Mô tả |
| --- | --- | --- |
| `ES_URLS` | - | Danh sách URL Elasticsearch, phân tách bằng dấu phẩy. Có giá trị → `/readyz` kiểm tra cluster health |

## Sẽ thêm ở các phase sau (SPEC §17.8)

`PG_REPLICA_DSN`, `KAFKA_BROKERS`, `ES_API_KEY`, `REDIS_ADDR`, `S3_ENDPOINT`, `S3_BUCKET`,
`PRICE_CHANGE_THRESHOLD_PCT`, `IMPORT_MAX_FILE_MB`, `IMPORT_MAX_ERROR_RATIO`, `PRESENCE_TTL_SECONDS`
- mỗi biến được thêm cùng tính năng dùng đến nó, không khai báo trước.

## Frontend (`web/.env.local`, xem `web/.env.example`)

| Biến | Mặc định | Mô tả |
| --- | --- | --- |
| `VITE_OIDC_AUTHORITY` | `http://localhost:8081/realms/strata` | Keycloak realm |
| `VITE_OIDC_CLIENT_ID` | `web` | Client public (PKCE) |
| `VITE_GRAFANA_URL` | `http://localhost:3000` | Mục Dashboard trên sidebar |
| `VITE_AG_GRID_LICENSE_KEY` | - | License AG Grid Enterprise |
| `STRATA_COMMAND_URL` / `STRATA_QUERY_URL` | `http://localhost:8080` / `:8082` | Đích proxy của Vite dev server (biến của Node, không phải `VITE_`) |
