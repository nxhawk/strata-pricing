# Nhật ký lệch / bổ sung so với tài liệu gốc

Theo DoD chung (PLAN §2.5): "mọi lệch so với tài liệu gốc được ghi lại để cập nhật tài liệu".
Mỗi mục ghi: nội dung, lý do, tài liệu cần cập nhật. Trạng thái: **Đề xuất** (chờ review),
**Đã duyệt**, **Đã cập nhật tài liệu**.

## PH-01

| # | Nội dung | Lý do | Tài liệu cần cập nhật | Trạng thái |
| --- | --- | --- | --- | --- |
| D-01 | Module Go `github.com/nxhawk/strata-pricing`; monorepo nằm ở thư mục `strata/` | Chốt theo yêu cầu đầu vào PH-01 | ARCH §5.2 | Đã duyệt |
| D-02 | Go **1.24** (tài liệu: 1.23+) | Bản ổn định đang dùng; tương thích "1.23+" | - | Đề xuất |
| D-03 | Thư viện cấu hình **caarlos0/env v11** thay cho kelseyhightower/envconfig | envconfig với struct lồng tự rơi về tên biến không có tiền tố (`DSN` thay cho `PG_DSN`) và báo lỗi sai tên biến; caarlos0/env báo đúng tên đầy đủ, liệt kê mọi biến thiếu một lần, không phụ thuộc thêm. Chỉ dùng trong `internal/platform/config` | SPEC §5.3 (bảng tech stack) | Đề xuất |
| D-04 | Thứ tự middleware: request-id → tracing → observe (access log + metric) → recover → timeout → body-limit → authn | Để log của panic có request_id/trace_id và panic vẫn được tính là 500 trong metric | ARCH §6.1 bảng middleware | Đề xuất |
| D-05 | Timeout handler bằng deadline của context (mặc định 6s) thay cho `http.TimeoutHandler` | `TimeoutHandler` bọc thêm goroutine, bỏ header của handler và không trả problem+json; mọi I/O đã tôn trọng ctx, `WriteTimeout` của server là chốt cuối | ARCH §6.1 | Đề xuất |
| D-06 | `GET /query/me` trả thêm `permissions[]`, `allSuppliers`, `kind` | Frontend ẩn/hiện chức năng theo quyền do backend tính (một nguồn sự thật cho ma trận RBAC), không lặp lại logic | SPEC §13.3 | Đề xuất |
| D-07 | Thêm quyền `version.view` (xem danh sách File Version) và `dashboard.view` | UX §4.2 có quy định hiển thị nhưng ma trận SPEC §16.1 chưa có dòng tương ứng | SPEC §16.1 | Đề xuất |
| D-08 | Mục "Chờ duyệt" hiện cho EDITOR và MANAGER | Diễn giải UX §4.2 "người khác thấy danh sách của mình đã gửi" - người gửi là EDITOR | UX §4.2 | Đề xuất |
| D-09 | `supplier_scope` = `*` nghĩa là mọi NCC; lấy từ thuộc tính group Keycloak (`supplier-<MÃ>`, `supplier-ALL`) | VIEWER/AUDITOR/ADMIN cần đọc mọi NCC trong khi query luôn lọc theo scope (SPEC §16.2); group khớp ARCH §11.2 "mapper Keycloak từ group" | SPEC §13.1, §16.1 | Đề xuất |
| D-10 | User mẫu `manager` có scope ACME, BMI, CPC | Vấn đề mở Q5 chưa chốt; PH-02 sẽ hiện thực Authorizer theo quyết định Q5 | SPEC §23.2 Q5 | Chờ Q5 |
| D-11 | Client Keycloak `dev-cli` (direct access grant) **chỉ trong realm local** | Lấy token cho curl/Postman/test tự động; không tạo ở môi trường khác | - (chỉ local) | Đề xuất |
| D-12 | Kafka thêm listener `EXTERNAL://localhost:29092` | Tiến trình chạy trên host (`go run`, công cụ) mới kết nối được broker | SPEC §18.2 | Đề xuất |
| D-13 | Thêm Jaeger all-in-one vào docker-compose; Grafana có datasource Jaeger | Kiểm tra tracing NFR-15 trên máy dev (PLAN ma trận truy vết NFR-15) | SPEC §18.2 | Đề xuất |
| D-14 | Topic khai báo ở `deploy/kafka/topics.conf` (định dạng dòng) thay cho `topics.yaml`; RF = 1 ở local | Script bash không cần parser YAML; production dùng Strimzi KafkaTopic (ARCH §8.1) | ARCH Phụ lục B | Đề xuất |
| D-15 | Quy tắc import giữa các lớp kiểm bằng `depguard` (golangci-lint), chưa dùng `go-arch-lint` | Một công cụ là đủ cho quy tắc hiện tại; tránh trùng cấu hình | ARCH §5.1, §16 | Đề xuất |
| D-16 | JWKS: khoá được cache trong bộ nhớ, chỉ tải lại khi gặp `kid` lạ (go-oidc RemoteKeySet) thay vì làm mới mỗi 10 phút | Keycloak gián đoạn không ảnh hưởng token đang dùng; xoay khoá vẫn được nhận nhờ `kid` mới | ARCH §6.1 bước 7 | Đề xuất |
| D-17 | Readiness không phụ thuộc Keycloak | Đúng tinh thần ARCH §10.6 (token cũ + JWKS cache vẫn dùng được) | - | Đề xuất |
| D-18 | Thư viện frontend bổ sung: react-router-dom 6, oidc-client-ts + react-oidc-context, i18next + react-i18next, lucide-react, @fontsource (Inter, JetBrains Mono) | SPEC §5.3 chỉ nêu React, TanStack Query, Zustand, AG Grid; đây là các lựa chọn phổ biến, không phụ thuộc server. Font tự host thay CDN | SPEC §5.3 | Đề xuất |
| D-19 | Access token lưu `sessionStorage`; tuỳ chọn giao diện (ngôn ngữ, mật độ grid, sidebar) lưu `localStorage` | Đồng bộ tuỳ chọn lên server (`/users/me/preferences`, SPEC §15.5) làm ở phase có API đó | UX §6.5 "lưu theo tài khoản" | Đề xuất |
| D-20 | Chưa dựng API gateway ở local; Vite dev server proxy `/api/v1/commands` và `/api/v1/query` | PLAN §2.6 bỏ phần triển khai; service vẫn tự verify JWT nên an toàn khi gọi trực tiếp | FLOW Luồng 1 | Đề xuất |
| D-21 | Bỏ qua PgBouncer ở local | PLAN §1.2 cho phép | - | Đã duyệt |
