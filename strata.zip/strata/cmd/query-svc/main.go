// query-svc: phía đọc (CQRS). Dịch request grid/search/as-of thành truy vấn
// Elasticsearch (từ PH-05). PH-01 cung cấp GET /api/v1/query/me.
package main

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"

	httpin "github.com/nxhawk/strata-pricing/internal/adapter/in/http"
	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/queryapi"
	"github.com/nxhawk/strata-pricing/internal/adapter/out/oidc"
	"github.com/nxhawk/strata-pricing/internal/platform/health"
	"github.com/nxhawk/strata-pricing/internal/platform/metrics"
	"github.com/nxhawk/strata-pricing/internal/platform/service"
)

// Config của query-svc (SPEC §17.8).
type Config struct {
	service.Base
	OIDC oidc.Config `envPrefix:"OIDC_"`
	// ES_URLS: danh sách URL Elasticsearch, cách nhau dấu phẩy. Khi có, readiness
	// kiểm tra cluster health. Client ES đầy đủ được thêm ở PH-05.
	ESURLs []string `env:"ES_URLS" envSeparator:","`
}

func main() {
	service.Main("query-svc", func(ctx context.Context, k *service.Kit, cfg Config) error {
		verifier, err := oidc.NewVerifier(ctx, cfg.OIDC)
		if err != nil {
			return err
		}
		if len(cfg.ESURLs) > 0 {
			url := strings.TrimRight(cfg.ESURLs[0], "/") + "/_cluster/health"
			k.Health.AddCheck("elasticsearch", 2*time.Second, health.HTTPCheck(&http.Client{}, url))
		}

		router := httpin.NewRouter(httpin.Deps{
			Logger:   k.Log,
			Metrics:  metrics.NewHTTP(k.Metrics.Registerer),
			Verifier: verifier,
		}, "/api/v1/query", queryapi.New().Mount)

		if err := k.AddHTTP("api", cfg.HTTPAddr, router); err != nil {
			return fmt.Errorf("api server: %w", err)
		}
		return nil
	})
}
