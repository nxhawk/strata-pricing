// import-worker: consume FileUploaded, parse/validate file giá, COPY vào staging, diff, tạo bản nháp (SPEC §9.3).
//
// PH-01 chỉ dựng khung service (cấu hình, log, tracing, /livez /readyz /metrics,
// tắt êm) để docker-compose chạy đủ thành phần. Logic nghiệp vụ đến ở PH-07.
package main

import (
	"context"

	"github.com/nxhawk/strata-pricing/internal/platform/service"
)

// Config của import-worker.
type Config struct {
	service.Base
}

func main() {
	service.Main("import-worker", func(ctx context.Context, k *service.Kit, _ Config) error {
		k.Log.InfoContext(ctx, "skeleton service: no workload yet", "planned_phase", "PH-07")
		return nil
	})
}
