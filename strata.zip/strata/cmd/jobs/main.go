// jobs: tác vụ nền: publisher, activator giá tương lai, watchdog, dọn dẹp (ARCH §6.6).
//
// PH-01 chỉ dựng khung service (cấu hình, log, tracing, /livez /readyz /metrics,
// tắt êm) để docker-compose chạy đủ thành phần. Logic nghiệp vụ đến ở PH-11.
package main

import (
	"context"

	"github.com/nxhawk/strata-pricing/internal/platform/service"
)

// Config của jobs.
type Config struct {
	service.Base
}

func main() {
	service.Main("jobs", func(ctx context.Context, k *service.Kit, _ Config) error {
		k.Log.InfoContext(ctx, "skeleton service: no workload yet", "planned_phase", "PH-11")
		return nil
	})
}
