// command-svc: phía ghi (CQRS). Nhận command, kiểm tra nghiệp vụ, ghi SCD2 +
// outbox trong một transaction (từ PH-03). PH-01 dựng khung: xác thực,
// problem+json, kết nối PostgreSQL, readiness, metric.
package main

import (
	"context"
	"fmt"
	"time"

	httpin "github.com/nxhawk/strata-pricing/internal/adapter/in/http"
	"github.com/nxhawk/strata-pricing/internal/adapter/in/http/commandapi"
	"github.com/nxhawk/strata-pricing/internal/adapter/out/oidc"
	"github.com/nxhawk/strata-pricing/internal/adapter/out/postgres"
	"github.com/nxhawk/strata-pricing/internal/platform/metrics"
	"github.com/nxhawk/strata-pricing/internal/platform/service"
)

// Config của command-svc (SPEC §17.8). Ngưỡng nghiệp vụ (PRICE_CHANGE_THRESHOLD_PCT...)
// được thêm cùng tính năng dùng đến chúng.
type Config struct {
	service.Base
	PG   postgres.Config `envPrefix:"PG_"`
	OIDC oidc.Config     `envPrefix:"OIDC_"`
}

func main() {
	service.Main("command-svc", func(ctx context.Context, k *service.Kit, cfg Config) error {
		pool, err := postgres.NewPool(ctx, cfg.PG, "command-svc")
		if err != nil {
			return err
		}
		k.OnStop(func(context.Context) error { pool.Close(); return nil })
		k.Health.AddCheck("postgres", 2*time.Second, postgres.HealthCheck(pool))

		verifier, err := oidc.NewVerifier(ctx, cfg.OIDC)
		if err != nil {
			return err
		}

		router := httpin.NewRouter(httpin.Deps{
			Logger:   k.Log,
			Metrics:  metrics.NewHTTP(k.Metrics.Registerer),
			Verifier: verifier,
		}, "/api/v1/commands", commandapi.New().Mount)

		if err := k.AddHTTP("api", cfg.HTTPAddr, router); err != nil {
			return fmt.Errorf("api server: %w", err)
		}
		return nil
	})
}
