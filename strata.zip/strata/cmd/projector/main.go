// projector: consume event từ Kafka, cập nhật các index Elasticsearch idempotent (SPEC §11.5).
//
// PH-01 chỉ dựng khung service (cấu hình, log, tracing, /livez /readyz /metrics,
// tắt êm) để docker-compose chạy đủ thành phần. Logic nghiệp vụ đến ở PH-04.
package main

import (
	"context"

	"github.com/nxhawk/strata-pricing/internal/platform/service"
)

// Config của projector.
type Config struct {
	service.Base
}

func main() {
	service.Main("projector", func(ctx context.Context, k *service.Kit, _ Config) error {
		k.Log.InfoContext(ctx, "skeleton service: no workload yet", "planned_phase", "PH-04")
		return nil
	})
}
