// notifier: đẩy thay đổi realtime qua WebSocket và quản lý presence trong Redis (SPEC §14).
//
// PH-01 chỉ dựng khung service (cấu hình, log, tracing, /livez /readyz /metrics,
// tắt êm) để docker-compose chạy đủ thành phần. Logic nghiệp vụ đến ở PH-10.
package main

import (
	"context"

	"github.com/nxhawk/strata-pricing/internal/platform/service"
)

// Config của notifier.
type Config struct {
	service.Base
}

func main() {
	service.Main("notifier", func(ctx context.Context, k *service.Kit, _ Config) error {
		k.Log.InfoContext(ctx, "skeleton service: no workload yet", "planned_phase", "PH-10")
		return nil
	})
}
